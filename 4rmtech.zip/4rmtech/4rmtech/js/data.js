/* 4RMTECH – editable site data.
   Everything here is DEMO data. Replace with real inventory / API calls later.
   To connect a backend, replace window.API at the bottom of this file. */

window.SITE = {
  name: "4RMTECH",
  email: "info@your-domain.example",        // placeholder – replace
  phone: "+63 000 000 0000",                 // placeholder – replace
  address: "Your business address, City, Philippines", // placeholder – replace
  hours: "Business hours: add here",
  // "auto" = the store server (npm start) passes requests on to the admin server for you. Or put the admin's
  // full address here, e.g. "https://admin.example.com".
  // URL of the 4RMTECH admin server. Products come from its database, and the contact form and
  // checkout send their data to it. If it is unreachable the site falls back to the demo data in this
  // file. Set to "" to run the storefront on its own. Use your real https address when you go live.
  apiBase: "auto",
  social: {
    // Add real URLs to show icons/links in the footer, e.g.
    // facebook: "https://facebook.com/your-page",
    // instagram: "", youtube: "", tiktok: "", linkedin: ""
  },
  about: {
    overview: "Company overview placeholder. Describe how 4RMTECH helps customers find technology products and IT solutions that fit their work, business and daily life.",
    mission: "Mission placeholder: add your mission statement here.",
    vision: "Vision placeholder: add your vision statement here.",
    history: "Company history placeholder: add when and how 4RMTECH started, in your own words.",
    location: "Business location placeholder: add your store or office location.",
    contact: "Contact placeholder: add your preferred contact details."
  }
};

window.CATEGORIES = [
  { id: "laptops",    name: "Laptops & Computers",       desc: "Notebooks, desktops and all-in-ones for work and play." },
  { id: "components", name: "Computer Components",       desc: "Processors, graphics cards, memory and motherboards." },
  { id: "monitors",   name: "Monitors & Displays",       desc: "Office, creator and gaming displays in every size." },
  { id: "networking", name: "Networking Equipment",      desc: "Routers, switches and access points for reliable coverage." },
  { id: "accessories",name: "Computer Accessories",      desc: "Keyboards, mice, headsets, webcams and hubs." },
  { id: "storage",    name: "Storage Devices",           desc: "SSDs, hard drives and flash drives for every budget." },
  { id: "printers",   name: "Printers & Office Equipment",desc: "Printers, scanners and everyday office gear." },
  { id: "power",      name: "Power Solutions",           desc: "UPS units, surge protection and power supplies." }
];

/* tags: featured | bestseller | new | recommended | offer
   popularity & added are demo sort values. rating:null means no real review data. */
window.PRODUCTS = [
  { id: 1,  name: "Vivobook 15 Laptop",        brand: "ASUS",     model: "X1504",        category: "laptops",     price: 34995, oldPrice: 38995, stock: 12, popularity: 88, added: "2026-09-20", tags: ["featured","offer"], specs: ["15.6\" FHD display","Intel Core i5","16GB RAM / 512GB SSD"] },
  { id: 2,  name: "IdeaPad Slim 3",            brand: "Lenovo",   model: "15IAH8",       category: "laptops",     price: 29995, oldPrice: null,  stock: 8,  popularity: 92, added: "2026-08-14", tags: ["bestseller"], specs: ["15.6\" FHD display","Intel Core i3","8GB RAM / 256GB SSD"] },
  { id: 3,  name: "Aspire Go 14",              brand: "Acer",     model: "AG14-31P",     category: "laptops",     price: 22995, oldPrice: 24995, stock: 20, popularity: 70, added: "2026-07-02", tags: ["recommended","offer"], specs: ["14\" FHD display","Intel N-series","8GB RAM / 256GB SSD"] },
  { id: 4,  name: "Ryzen 5 Desktop Processor", brand: "AMD",      model: "Ryzen 5 7600", category: "components",  price: 12495, oldPrice: 13995, stock: 15, popularity: 84, added: "2026-06-18", tags: ["bestseller","offer"], specs: ["6 cores / 12 threads","AM5 socket","Cooler included"] },
  { id: 5,  name: "GeForce RTX 4060 Graphics Card", brand: "MSI", model: "Ventus 2X",   category: "components",  price: 21995, oldPrice: null,  stock: 5,  popularity: 90, added: "2026-09-02", tags: ["featured"], specs: ["8GB GDDR6","Dual-fan cooling","HDMI + DisplayPort"] },
  { id: 6,  name: "Fury Beast DDR5 32GB Kit",  brand: "Kingston", model: "KF560C36BBEK2-32", category: "components", price: 7495, oldPrice: 8295, stock: 30, popularity: 76, added: "2026-09-28", tags: ["new","offer"], specs: ["2 x 16GB","6000 MT/s","XMP 3.0"] },
  { id: 7,  name: "24\" IPS Full HD Monitor",  brand: "Samsung",  model: "S24C310",      category: "monitors",    price: 6995,  oldPrice: null,  stock: 25, popularity: 81, added: "2026-05-11", tags: ["bestseller","recommended"], specs: ["24\" IPS panel","75Hz","HDMI + VGA"] },
  { id: 8,  name: "27\" QHD Gaming Monitor",   brand: "MSI",      model: "G274QPF",      category: "monitors",    price: 16995, oldPrice: 18995, stock: 6,  popularity: 79, added: "2026-10-01", tags: ["new","featured","offer"], specs: ["27\" QHD IPS","170Hz","1ms response"] },
  { id: 9,  name: "Archer AX23 Wi-Fi 6 Router",brand: "TP-Link",  model: "AX1800",       category: "networking",  price: 3495,  oldPrice: null,  stock: 40, popularity: 86, added: "2026-04-22", tags: ["bestseller","recommended"], specs: ["Wi-Fi 6 dual band","4 antennas","Gigabit LAN"] },
  { id: 10, name: "8-Port Gigabit Switch",     brand: "TP-Link",  model: "TL-SG108",     category: "networking",  price: 1295,  oldPrice: 1495,  stock: 50, popularity: 68, added: "2026-03-30", tags: ["offer"], specs: ["8 x 10/100/1000 ports","Plug and play","Metal casing"] },
  { id: 11, name: "Deco X20 Mesh Wi-Fi (2-Pack)", brand: "TP-Link", model: "X20",       category: "networking",  price: 7995,  oldPrice: null,  stock: 14, popularity: 73, added: "2026-09-25", tags: ["new","recommended"], specs: ["Whole-home mesh","Wi-Fi 6","App setup"] },
  { id: 12, name: "MX Keys S Wireless Keyboard", brand: "Logitech", model: "MX Keys S",  category: "accessories", price: 6495,  oldPrice: null,  stock: 18, popularity: 77, added: "2026-08-05", tags: ["featured"], specs: ["Backlit keys","Multi-device","USB-C rechargeable"] },
  { id: 13, name: "M331 Silent Wireless Mouse",brand: "Logitech", model: "M331",         category: "accessories", price: 995,   oldPrice: 1195,  stock: 60, popularity: 83, added: "2026-02-10", tags: ["bestseller","offer"], specs: ["Silent clicks","2.4GHz USB receiver","Compact design"] },
  { id: 14, name: "C920 HD Pro Webcam",        brand: "Logitech", model: "C920",         category: "accessories", price: 3995,  oldPrice: null,  stock: 22, popularity: 71, added: "2026-01-19", tags: ["recommended"], specs: ["1080p video","Dual microphones","Universal clip"] },
  { id: 15, name: "NV2 NVMe SSD 1TB",          brand: "Kingston", model: "SNV2S/1000G",  category: "storage",     price: 3995,  oldPrice: 4695,  stock: 35, popularity: 89, added: "2026-09-10", tags: ["bestseller","offer"], specs: ["PCIe 4.0 NVMe","M.2 2280","1TB capacity"] },
  { id: 16, name: "Portable SSD T7 1TB",       brand: "Samsung",  model: "MU-PC1T0T",    category: "storage",     price: 6995,  oldPrice: null,  stock: 16, popularity: 80, added: "2026-10-04", tags: ["new","featured"], specs: ["USB 3.2 Gen 2","Pocket sized","1TB capacity"] },
  { id: 17, name: "My Passport 2TB Hard Drive",brand: "Western Digital", model: "WDBPKJ0020", category: "storage", price: 5295, oldPrice: null,  stock: 28, popularity: 74, added: "2026-03-08", tags: ["recommended"], specs: ["2TB capacity","USB 3.0","Backup software"] },
  { id: 18, name: "EcoTank L3250 Printer",     brand: "Epson",    model: "L3250",        category: "printers",    price: 9995,  oldPrice: 10995, stock: 11, popularity: 87, added: "2026-06-01", tags: ["bestseller","offer"], specs: ["Print / scan / copy","Wi-Fi","Refillable ink tanks"] },
  { id: 19, name: "LaserJet M111w Printer",    brand: "HP",       model: "M111w",        category: "printers",    price: 6495,  oldPrice: null,  stock: 9,  popularity: 66, added: "2026-04-15", tags: ["recommended"], specs: ["Mono laser","Wi-Fi","Compact design"] },
  { id: 20, name: "Back-UPS 650VA",            brand: "APC",      model: "BX650LI-MS",   category: "power",       price: 3295,  oldPrice: null,  stock: 24, popularity: 78, added: "2026-05-27", tags: ["featured","recommended"], specs: ["650VA / 325W","AVR","Multiple outlets"] },
  { id: 21, name: "Back-UPS Pro 1500VA",       brand: "APC",      model: "BR1500G-AS",   category: "power",       price: 12995, oldPrice: 14495, stock: 7,  popularity: 72, added: "2026-09-15", tags: ["offer"], specs: ["1500VA / 865W","LCD status","USB charging port"] },
  { id: 22, name: "RM750e 750W Power Supply",  brand: "Corsair",  model: "RM750e",       category: "power",       price: 6995,  oldPrice: null,  stock: 13, popularity: 69, added: "2026-10-06", tags: ["new"], specs: ["80 Plus Gold","Fully modular","Quiet fan"] },
  { id: 23, name: "USB-C 7-in-1 Hub",          brand: "Anker",    model: "A8352",        category: "accessories", price: 2495,  oldPrice: 2995,  stock: 45, popularity: 75, added: "2026-10-08", tags: ["new","offer"], specs: ["HDMI 4K output","SD / microSD","USB-C power pass-through"] },
  { id: 24, name: "Core i5 Office Desktop PC", brand: "Lenovo",   model: "ThinkCentre Neo 50s", category: "laptops", price: 32995, oldPrice: null, stock: 10, popularity: 65, added: "2026-07-21", tags: ["recommended","featured"], specs: ["Intel Core i5","16GB RAM / 512GB SSD","Windows 11 Pro"] }
];

/* ---- Backend seam -------------------------------------------------------
   The UI only talks to window.API. Swap these functions for fetch() calls to
   your database, auth provider and payment gateway when they exist. */
window.API = {
  getProducts: async () => window.PRODUCTS,
  getProduct:  async (id) => window.PRODUCTS.find(p => p.id === Number(id)) || null,
  login:       async (user) => user,   // replace with real authentication
  getOrders:   async () => [],         // replace with real order history
  submitContact: null,                 // set to async (data) => {...} to deliver messages
  placeOrder:  null                    // set to async (cart, details) => {...} to take orders
};

/* Connect to the admin server when SITE.apiBase is set (falls back to demo data if it is unreachable). */
(function () {
  var base = String(window.SITE.apiBase || "").replace(/\/+$/, "");
  if (base === "auto") base = (typeof location !== "undefined" && /^https?:$/.test(location.protocol)) ? "" : null;   // same address as this page
  if (base === null) { window.API.live = false; return; }
  window.API.live = false;            // true once products have been loaded from the admin database
  if (!window.SITE.apiBase) return;
  var demo = window.API.getProducts;
  async function post(path, data) {
    var r = await fetch(base + path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    var body = {}; try { body = await r.json(); } catch (e) { /* no body */ }
    if (!r.ok) throw new Error(body.error || "Request failed");
    return body;
  }
  window.API.getProducts = async function () {
    try {
      var r = await fetch(base + "/public/products", { cache: "no-store" });
      if (!r.ok) throw new Error("bad status");
      var list = await r.json();
      window.API.live = true;
      return Array.isArray(list) ? list : demo();
    } catch (e) { window.API.live = false; return demo(); }
  };
  // Live updates: the admin pushes a "changed" signal; onChange is called so the page can re-download
  // the products. EventSource reconnects by itself, and every (re)connect triggers one refresh.
  window.API.subscribe = function (onChange) {
    if (typeof EventSource === "undefined") return function () {};
    var es, first = true;
    try {
      es = new EventSource(base + "/public/events");
      es.addEventListener("changed", function () { onChange(); });
      es.addEventListener("hello", function () { if (first) first = false; else onChange(); });
    } catch (e) { return function () {}; }
    return function () { es.close(); };
  };
  window.API.submitContact = function (d) { return post("/public/contact", d); };
  window.API.placeOrder = function (cart, customer) { return post("/public/orders", { customer: customer, items: cart }); };
})();

/* Services & FAQs – edit freely. */
window.SERVICES = [
  { icon: "chip",   title: "Computer Hardware & Software Solutions", text: "Help choosing, sourcing and installing the right hardware and software." },
  { icon: "wrench", title: "Computer Setup & Configuration",         text: "New device setup, data transfer and system configuration." },
  { icon: "headset",title: "IT Support & Troubleshooting",           text: "Diagnosis and repair of common hardware, software and connectivity issues." },
  { icon: "network",title: "Networking Solutions",                   text: "Wired and wireless network planning and installation for homes and offices." },
  { icon: "code",   title: "Website Development",                    text: "Business websites and online stores built to fit your needs." },
  { icon: "briefcase", title: "Business Technology Solutions",       text: "Technology planning and equipment for growing businesses." }
];

window.FAQS = [
  { q: "Are the products and prices on this site real?", a: "This is a demo catalog. Sample products, prices and stock counts are placeholders until your actual inventory is connected." },
  { q: "How do I place an order?", a: "Checkout is not connected to a payment gateway or backend yet, so orders can't be placed on this demo. Add your payment provider to enable it." },
  { q: "What is your return and refund policy?", a: "Add your return and refund policy here." },
  { q: "Do you offer delivery?", a: "Add your delivery areas, fees and timelines here." },
  { q: "How can I reach support?", a: "Use the contact form or the email and phone details in the Contact section once they are filled in." }
];