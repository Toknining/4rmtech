'use strict';
/* 4RMTECH storefront server.
   The landing page must be opened through this server (npm start), not by double-clicking index.html.
   - serves ONLY index.html, /css and /js
   - forwards /public/* (products, live-update stream, orders, contact) to the admin server, so the
     browser only ever talks to one address and the admin/database is never exposed directly
   - starts the admin server for you (unless one is already running) */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const ROOT = __dirname;
const PORT = Number(process.env.SITE_PORT) || 3000;
const HOST = process.env.SITE_HOST || '127.0.0.1';
const ADMIN = new URL(process.env.ADMIN_URL || 'http://127.0.0.1:4000');
const SITE_ONLY = process.argv.includes('--site-only');

const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp' };

function headers(extra) {
  return Object.assign({
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Cache-Control': 'no-cache'
  }, extra);
}
function text(res, code, msg) { res.writeHead(code, headers({ 'Content-Type': 'text/plain; charset=utf-8' })); res.end(msg); }

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return text(res, 405, 'Method not allowed');
  let rel; try { rel = decodeURIComponent(pathname); } catch (e) { return text(res, 400, 'Bad path'); }
  if (rel === '/' ) rel = '/index.html';
  if (!(rel === '/index.html' || rel.startsWith('/css/') || rel.startsWith('/js/') || rel.startsWith('/assets/'))) rel = '/index.html'; // single-page app fallback
  const file = path.resolve(ROOT, '.' + rel);
  if (file !== path.join(ROOT, 'index.html') && !['css', 'js', 'assets'].some(d => file.startsWith(path.join(ROOT, d) + path.sep))) return text(res, 403, 'Forbidden');
  fs.readFile(file, (err, data) => {
    if (err) return text(res, 404, 'Not found');
    res.writeHead(200, headers({ 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' }));
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

function proxy(req, res) {
  const h = Object.assign({}, req.headers, { host: ADMIN.host, 'x-forwarded-for': req.socket.remoteAddress || '' });
  delete h.connection;
  const up = http.request({ hostname: ADMIN.hostname, port: ADMIN.port, path: req.url, method: req.method, headers: h }, ur => {
    const out = Object.assign({}, ur.headers);
    res.writeHead(ur.statusCode, out);
    ur.pipe(res);
    if ((out['content-type'] || '').startsWith('text/event-stream')) res.flushHeaders();
  });
  up.on('error', () => { if (!res.headersSent) text(res, 502, 'Store server (admin) is not running'); else res.end(); });
  res.on('close', () => up.destroy());
  req.pipe(up);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/public/')) return proxy(req, res);
  serveStatic(req, res, url.pathname);
});

/* ---- start the admin server too, unless it is already running ---- */
let child = null;
function adminUp() {
  return new Promise(resolve => {
    const r = http.get({ hostname: ADMIN.hostname, port: ADMIN.port, path: '/public/products', headers: { host: ADMIN.host }, timeout: 1500 }, x => { x.resume(); resolve(true); });
    r.on('error', () => resolve(false)); r.on('timeout', () => { r.destroy(); resolve(false); });
  });
}
async function startAdmin() {
  if (SITE_ONLY) return console.log('Admin server not started (--site-only). Start it with: cd admin && npm run dev');
  if (await adminUp()) return console.log('Admin server already running at ' + ADMIN.origin);
  const dir = path.join(ROOT, 'admin');
  if (!fs.existsSync(path.join(dir, 'server.js'))) return console.log('admin/server.js not found: only the demo catalogue will show.');
  child = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'server.js'], { cwd: dir, stdio: 'inherit', env: process.env });
  child.on('exit', code => { child = null; console.log('Admin server stopped (code ' + code + ').'); });
}
function stop() { if (child) child.kill(); process.exit(0); }
process.on('SIGINT', stop); process.on('SIGTERM', stop);
process.on('exit', () => { if (child) child.kill(); });

server.on('error', e => { console.error(e.code === 'EADDRINUSE' ? `Port ${PORT} is already in use. Set SITE_PORT to another number.` : e.message); process.exit(1); });
server.listen(PORT, HOST, () => {
  console.log('\n  4RMTECH store:  http://localhost:' + PORT + '\n');
  startAdmin();
});