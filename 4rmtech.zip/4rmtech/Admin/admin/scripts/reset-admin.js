'use strict';
// Usage: npm run reset-admin
// Generates a new random password for the built-in "admin" account, signs out every session,
// and forces a password change at next login.
require('../lib/env');
const { init, db } = require('../lib/db');
const auth = require('../lib/auth');

(async () => {
  await init();
  const password = auth.randomPassword();
  await auth.upsertAdmin('admin', password);
  console.log('\n  Admin account reset.');
  console.log('  Username : admin');
  console.log('  Password : ' + password);
  console.log('  You will be asked to choose a new password at first login.\n');
  await db.close();
})().catch(e => { console.error('Reset failed:', e.message); process.exit(1); });
