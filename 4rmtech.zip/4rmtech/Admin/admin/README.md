# 4RMTECH Admin

A separate Node.js app that manages the store and holds its database. It is **not** part of the landing
page: nothing on the storefront links to it, and it runs as its own server.

```
Storefront (index.html)  <---- products, orders, messages ---->  Admin server  <---->  Database
   customers use this                                            localhost:4000        PostgreSQL (or SQLite)
```

## 1. Quick start (no database to install: uses built-in SQLite)

Requires Node.js 22.13 or newer.

```
cd admin
npm run dev
```

Open http://localhost:4000 and sign in with the built-in account that the terminal prints **once**:

- Username: `admin`
- Password: a random one generated for you (or `ADMIN_INITIAL_PASSWORD` from `.env`)

You must choose a new password (12+ characters) at first login. Forgot it? `npm run reset-admin`.

## 2. Use PostgreSQL (recommended for a real store)

1. Install PostgreSQL (postgresql.org/download, version 18) and remember the `postgres` password.
2. Create an empty database. Open **SQL Shell (psql)** from the Start menu, press Enter through the
   prompts, type the password, then run:
   ```
   CREATE DATABASE fourtech;
   ```
3. In the `admin` folder, copy `.env.example` to `.env` and set:
   ```
   DATABASE_URL=postgres://postgres:YOUR_PASSWORD@localhost:5432/fourtech
   ```
   (If the password contains `@ : / # ?`, URL-encode it, e.g. `@` becomes `%40`.)
4. Install the PostgreSQL driver once, then start:
   ```
   npm install
   npm run dev
   ```
The terminal prints `Database: PostgreSQL`. The tables are created automatically and filled with the demo
products on first start. Hosted databases (Supabase, Neon, ...) work too: paste their connection URL.

Note: switching database does not copy old data. The first start on a new database begins with the demo
products and a new built-in admin account.

## 3. How the storefront is connected

`js/data.js` has `apiBase: "http://localhost:4000"`. With the admin running:

- Products on the storefront come from the database. Edit a product in the admin and refresh the store.
  Hidden products are not shown. Prices and stock are shown as real (the "demo" labels disappear).
- **Checkout** sends an *order request* to the admin (Orders page). Prices and stock are always checked
  against the database on the server, never trusted from the browser. **No payment is taken online.**
  You confirm with the customer, then set the status. *Confirmed* removes the items from stock,
  *Cancelled* puts them back.
- The **contact form** delivers to the admin Messages page.
- If the admin is not running, the storefront falls back to its built-in demo data, and checkout and the
  contact form say plainly that nothing was sent.

## 4. What the admin does

Dashboard, Products (add / edit / hide / delete), Orders (status workflow), Messages, Activity log, Account.

## 5. How the database and account are protected

- Passwords are hashed with scrypt (salted). Session tokens are random and stored only as hashes.
- Session cookie is HttpOnly + SameSite=Strict; every change needs a CSRF token and a same-origin request.
- 5 failed logins lock that user/IP for 15 minutes. Login, contact and order endpoints are rate limited.
- The server listens on 127.0.0.1 only, rejects unknown Host headers, and sends strict security headers.
- All queries are parameterised and all input is validated on the server.
- The SQLite file lives in `admin/data/` (never served, git-ignored). Keep `.env` private too: it holds
  your database password.
- Sign-ins, failures, product, order and password changes are recorded in the Activity log.
- The public API only exposes: read products, send a contact message, send an order request.

## 6. Before going live

- The public storefront must be able to reach the admin server's `/public/*` address. Put the admin behind
  HTTPS (reverse proxy), set `SECURE_COOKIES=1`, `HOST`, `ALLOWED_HOSTS` and your store's address in
  `PUBLIC_ORIGINS` in `.env`, and set `apiBase` in `js/data.js` to that address. Restrict who can open the
  admin pages themselves (for example by IP or VPN).
- Back up the database regularly.
- To take online payments, use a payment provider's hosted checkout; never store card numbers.
