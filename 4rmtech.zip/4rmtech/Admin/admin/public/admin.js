/* 4RMTECH admin UI. No inline styles/handlers (the server's CSP forbids them). */
(function () {
  'use strict';
  const root = document.getElementById('root');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const peso = n => '₱' + Number(n).toLocaleString('en-PH', { maximumFractionDigits: 2 });
  const $ = (s, r = document) => r.querySelector(s);
  const S = { user: null, csrf: '', meta: null, view: 'dashboard', products: [], unread: 0 };
  const VIEWS = [['dashboard', 'Dashboard'], ['products', 'Products'], ['messages', 'Messages'], ['orders', 'Orders'], ['activity', 'Activity log'], ['account', 'Account']];

  async function api(method, url, body) {
    const opt = { method, credentials: 'same-origin', headers: {} };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    if (method !== 'GET') opt.headers['X-CSRF-Token'] = S.csrf;
    const res = await fetch(url, opt);
    let data = {}; try { data = await res.json(); } catch (e) { /* empty */ }
    if (!res.ok) {
      if (res.status === 401 && url !== '/api/login' && url !== '/api/session') { S.user = null; showLogin('Your session ended. Please sign in again.'); }
      if (res.status === 403 && data.error === 'password_change_required') { showChange(true); }
      const err = new Error(data.error || 'Request failed'); err.status = res.status; throw err;
    }
    return data;
  }

  /* ---------- login / forced password change ---------- */
  function brand() { return '<div class="brand">4RM<b>TECH</b><small>ADMIN</small></div>'; }
  function showLogin(msg) {
    root.innerHTML = `<div class="center"><form class="login" id="loginForm" autocomplete="on">
      ${brand()}<h1>Sign in</h1><p>Authorised staff only.</p>
      <div class="field"><label for="u">Username</label><input id="u" name="username" autocomplete="username" required maxlength="64"></div>
      <div class="field"><label for="p">Password</label><input id="p" name="password" type="password" autocomplete="current-password" required maxlength="256"></div>
      <button class="btn primary block" type="submit">Sign in</button>
      <div id="loginMsg" aria-live="polite">${msg ? `<div class="notice err">${esc(msg)}</div>` : ''}</div></form></div>`;
    $('#u').focus();
  }
  function showChange(forced, msg) {
    root.innerHTML = `<div class="center"><form class="login" id="changeForm">
      ${brand()}<h1>${forced ? 'Choose a new password' : 'Change password'}</h1>
      <p>${forced ? 'For security you must replace the initial password before continuing.' : 'Use at least 12 characters.'}</p>
      <div class="field"><label for="c">Current password</label><input id="c" name="current" type="password" autocomplete="current-password" required></div>
      <div class="field"><label for="n">New password</label><input id="n" name="next" type="password" autocomplete="new-password" required minlength="12" maxlength="128"><span class="hint">At least 12 characters. A passphrase of several words works well.</span></div>
      <div class="field"><label for="n2">Confirm new password</label><input id="n2" name="again" type="password" autocomplete="new-password" required></div>
      <button class="btn primary block" type="submit">Save password</button>
      <div id="changeMsg" aria-live="polite">${msg ? `<div class="notice err">${esc(msg)}</div>` : ''}</div></form></div>`;
    $('#c').focus();
  }

  /* ---------- shell ---------- */
  function shell() {
    root.innerHTML = `<div class="shell"><aside class="side">${brand()}
      ${VIEWS.map(v => `<button class="nav" data-view="${v[0]}">${v[1]}${v[0] === 'messages' ? '<span class="pill hidden" id="unreadPill">0</span>' : ''}</button>`).join('')}
      <div class="spacer"></div><div class="muted" id="who"></div>
      <button class="btn sm" data-act="logout">Sign out</button></aside>
      <main class="main" id="main" tabindex="-1"></main></div>
      <dialog id="pdlg"></dialog>`;
    $('#who').textContent = 'Signed in as ' + S.user;
  }
  async function go(view) {
    S.view = view;
    document.querySelectorAll('.nav').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    const main = $('#main'); main.innerHTML = '<p class="muted">Loading…</p>';
    try { await VIEW_FN[view](main); } catch (e) { if (e.status !== 401 && e.status !== 403) main.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; }
  }
  /* Quietly re-load the open page every few seconds so new orders / messages appear without a refresh.
     Skipped while the tab is hidden, a dialog is open, or you are typing / choosing something. */
  setInterval(async () => {
    if (document.hidden || !S.user || !S.view || S.view === 'account') return;
    const main = $('#main'), dlg = $('#pdlg');
    if (!main || (dlg && dlg.open)) return;
    const ae = document.activeElement;
    if (ae && main.contains(ae) && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)) return;
    if (S.view === 'products') {
      if ($('#pq') && $('#pq').value) return;
      try { const list = await api('GET', '/api/products'); if (JSON.stringify(list) !== JSON.stringify(S.products) && S.view === 'products' && !(dlg && dlg.open)) { S.products = list; drawProducts(''); } } catch (e) { /* retry later */ }
      return;
    }
    const sel = [...main.querySelectorAll('select')].some(s => s.value !== (s.querySelector('option[selected]') || {}).value);
    if (sel) return;                                         // an unsaved status choice
    const y = window.scrollY, view = S.view, tmp = document.createElement('div');
    try {
      await VIEW_FN[view](tmp);
      if (S.view !== view || (dlg && dlg.open)) return;
      if (tmp.innerHTML !== main.innerHTML) { main.innerHTML = tmp.innerHTML; window.scrollTo(0, y); }
    } catch (e) { /* ignore, next tick retries */ }
  }, 8000);
  const setUnread = n => { S.unread = n; const p = $('#unreadPill'); if (p) { p.textContent = n; p.classList.toggle('hidden', !n); } };

  /* ---------- views ---------- */
  const VIEW_FN = {
    async dashboard(main) {
      const d = await api('GET', '/api/dashboard'); setUnread(d.unreadMessages);
      const card = (n, l, cls = '') => `<div class="card ${cls}"><div class="n">${n}</div><div class="l">${l}</div></div>`;
      main.innerHTML = `<h1>Dashboard</h1><p class="sub">Overview of your store.</p>
        <div class="cards">${card(d.products, 'Products')}${card(d.active, 'Visible in store')}${card(d.lowStock, 'Low stock (5 or fewer)', d.lowStock ? 'warn' : '')}${card(d.outOfStock, 'Out of stock', d.outOfStock ? 'bad' : '')}${card(d.unreadMessages, 'Unread messages')}${card(d.pendingOrders, 'Pending orders', d.pendingOrders ? 'warn' : '')}${card(d.orders, 'Total orders')}</div>
        <div class="panel"><b>Security notes</b><ul class="muted dash-notes">
        <li>This admin only listens on this computer (127.0.0.1) unless you change HOST.</li>
        <li>Database in use: <b>${d.database === 'postgres' ? 'PostgreSQL' : 'SQLite (admin/data/store.db)'}</b>. It is never served over the web.</li>
        <li>Every sign-in, product change and password change is recorded in the Activity log.</li></ul></div>`;
    },

    async products(main) {
      if (!S.meta) S.meta = await api('GET', '/api/categories');
      S.products = await api('GET', '/api/products');
      main.innerHTML = `<div class="head"><div><h1>Products</h1><p class="sub">Add, edit, hide or delete products.</p></div>
        <div class="head"><input class="search" id="pq" type="search" placeholder="Search products…" aria-label="Search products"><button class="btn primary" data-act="new-product">+ Add product</button></div></div>
        <div id="ptable"></div>`;
      drawProducts('');
    },

    async messages(main) {
      const rows = await api('GET', '/api/messages'); setUnread(rows.filter(r => !r.is_read).length);
      main.innerHTML = `<h1>Messages</h1><p class="sub">Contact-form messages from the storefront.</p>` + (rows.length ? rows.map(r => `
        <article class="msg ${r.is_read ? '' : 'unread'}"><div class="top"><div><b>${esc(r.name)}</b> <span class="muted">&lt;${esc(r.email)}&gt;</span></div><span class="muted">${esc(r.created_at)} UTC</span></div>
        ${r.subject ? `<span class="badge">${esc(r.subject)}</span>` : ''}<p>${esc(r.message)}</p>
        <a class="btn sm" href="mailto:${encodeURIComponent(r.email)}">Reply by email</a>
        ${r.is_read ? '' : `<button class="btn sm" data-act="read-msg" data-id="${r.id}">Mark read</button>`}
        <button class="btn sm danger" data-act="del-msg" data-id="${r.id}">Delete</button></article>`).join('')
        : '<div class="empty panel">No messages yet. Messages appear here once the storefront contact form is connected to this server (see README).</div>');
    },

    async orders(main) {
      if (!S.meta) S.meta = await api('GET', '/api/categories');
      const rows = await api('GET', '/api/orders');
      main.innerHTML = `<h1>Orders</h1><p class="sub">Order requests from the storefront. No payment is taken online: confirm the order with the customer, then set the status. Confirming removes the items from stock; cancelling puts them back.</p>` + (rows.length ? rows.map(o => `
        <article class="msg ${o.status === 'pending' ? 'unread' : ''}"><div class="top"><div><b>#${o.id} · ${esc(o.customer)}</b> <span class="muted">&lt;${esc(o.email)}&gt; · ${esc(o.phone)}</span></div><span class="muted">${esc(o.created_at)} UTC</span></div>
        <div class="muted">${esc(o.address)}, ${esc(o.city)} ${esc(o.zip)}</div>
        <div class="table-wrap order-items"><table><tbody>${o.items.map(i => `<tr><td>${esc(i.name)}</td><td>${i.qty} × ${peso(i.unit_price)}</td><td class="actions">${peso(i.unit_price * i.qty)}</td></tr>`).join('')}
        <tr><td colspan="2"><b>Total</b></td><td class="actions"><b>${peso(o.total)}</b></td></tr></tbody></table></div>
        <div class="order-actions"><label class="muted" for="st_${o.id}">Status</label>
        <select id="st_${o.id}" class="search">${S.meta.statuses.map(t => `<option value="${t}" ${t === o.status ? 'selected' : ''}>${t}</option>`).join('')}</select>
        <button class="btn sm primary" data-act="set-status" data-id="${o.id}">Update status</button></div></article>`).join('')
        : '<div class="empty panel">No orders yet. Orders appear here when customers submit the storefront checkout (see README to connect it).</div>');
    },

    async activity(main) {
      const rows = await api('GET', '/api/audit');
      main.innerHTML = `<h1>Activity log</h1><p class="sub">Last ${rows.length} security-relevant events.</p>
        <div class="table-wrap"><table><thead><tr><th>When (UTC)</th><th>User</th><th>Action</th><th>Detail</th><th>IP</th></tr></thead><tbody>${rows.map(r => `<tr><td>${esc(r.at)}</td><td>${esc(r.admin)}</td><td><span class="badge ${r.action === 'login_failed' ? 'bad' : ''}">${esc(r.action)}</span></td><td>${esc(r.detail)}</td><td>${esc(r.ip)}</td></tr>`).join('')}</tbody></table></div>`;
    },

    async account(main) {
      main.innerHTML = `<h1>Account</h1><p class="sub">Signed in as <b>${esc(S.user)}</b>.</p>
        <div class="stack"><form class="panel" id="accForm"><h2>Change password</h2><br>
        <div class="field"><label for="ac">Current password</label><input id="ac" name="current" type="password" autocomplete="current-password" required></div>
        <div class="field"><label for="an">New password</label><input id="an" name="next" type="password" autocomplete="new-password" required minlength="12" maxlength="128"><span class="hint">At least 12 characters.</span></div>
        <div class="field"><label for="an2">Confirm new password</label><input id="an2" name="again" type="password" autocomplete="new-password" required></div>
        <button class="btn primary" type="submit">Update password</button><div id="accMsg" aria-live="polite"></div></form></div>`;
    }
  };

  /* ---------- products table + editor ---------- */
  const catName = id => (S.meta.categories.find(c => c.id === id) || {}).name || id;
  function drawProducts(q) {
    q = q.toLowerCase();
    const rows = S.products.filter(p => !q || [p.name, p.brand, p.model, catName(p.category)].join(' ').toLowerCase().includes(q));
    $('#ptable').innerHTML = rows.length ? `<div class="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(p => `<tr>
      <td><b>${esc(p.name)}</b><br><span class="muted">${esc(p.brand)} ${esc(p.model)}</span></td><td>${esc(catName(p.category))}</td>
      <td>${peso(p.price)}${p.oldPrice ? `<br><span class="muted"><s>${peso(p.oldPrice)}</s></span>` : ''}</td>
      <td><span class="badge ${p.stock === 0 ? 'bad' : p.stock <= 5 ? 'warn' : 'ok'}">${p.stock}</span></td>
      <td><span class="badge ${p.active ? 'ok' : ''}">${p.active ? 'Visible' : 'Hidden'}</span></td>
      <td class="actions"><button class="btn sm" data-act="edit-product" data-id="${p.id}">Edit</button><button class="btn sm danger" data-act="del-product" data-id="${p.id}">Delete</button></td></tr>`).join('')}</tbody></table></div>`
      : '<div class="empty panel">No products found.</div>';
  }
  function openEditor(p) {
    const isNew = !p; p = p || { name: '', brand: '', model: '', category: S.meta.categories[0].id, price: '', oldPrice: '', stock: 0, popularity: 50, added: new Date().toISOString().slice(0, 10), tags: [], specs: [], active: true };
    const dlg = $('#pdlg');
    dlg.innerHTML = `<form id="pform" data-id="${isNew ? '' : p.id}"><h2>${isNew ? 'Add product' : 'Edit product'}</h2>
      <div class="field"><label for="f_name">Name</label><input id="f_name" name="name" value="${esc(p.name)}" required maxlength="120"></div>
      <div class="row2"><div class="field"><label for="f_brand">Brand</label><input id="f_brand" name="brand" value="${esc(p.brand)}" required maxlength="60"></div>
      <div class="field"><label for="f_model">Model</label><input id="f_model" name="model" value="${esc(p.model)}" maxlength="60"></div></div>
      <div class="field"><label for="f_cat">Category</label><select id="f_cat" name="category">${S.meta.categories.map(c => `<option value="${esc(c.id)}" ${c.id === p.category ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
      <div class="row3"><div class="field"><label for="f_price">Price (₱)</label><input id="f_price" name="price" type="number" min="0" step="0.01" value="${esc(p.price)}" required></div>
      <div class="field"><label for="f_old">Original price (₱)</label><input id="f_old" name="oldPrice" type="number" min="0" step="0.01" value="${esc(p.oldPrice ?? '')}"><span class="hint">Leave empty if not on offer.</span></div>
      <div class="field"><label for="f_stock">Stock</label><input id="f_stock" name="stock" type="number" min="0" step="1" value="${esc(p.stock)}" required></div></div>
      <div class="row2"><div class="field"><label for="f_pop">Popularity (0-100)</label><input id="f_pop" name="popularity" type="number" min="0" max="100" step="1" value="${esc(p.popularity)}"></div>
      <div class="field"><label for="f_added">Date added</label><input id="f_added" name="added" type="date" value="${esc(p.added)}"></div></div>
      <div class="field"><label>Tags</label><div class="checks">${S.meta.tags.map(t => `<label><input type="checkbox" name="tag" value="${t}" ${p.tags.includes(t) ? 'checked' : ''}> ${t}</label>`).join('')}</div></div>
      <div class="field"><label for="f_specs">Specs (one per line, up to 8)</label><textarea id="f_specs" name="specs" rows="4">${esc(p.specs.join('\n'))}</textarea></div>
      <div class="field"><div class="checks"><label><input type="checkbox" name="active" ${p.active ? 'checked' : ''}> Visible in the store</label></div></div>
      <div id="pmsg" aria-live="polite"></div>
      <div class="dlg-actions"><button type="button" class="btn" data-act="close-dialog">Cancel</button><button class="btn primary" type="submit">${isNew ? 'Add product' : 'Save changes'}</button></div></form>`;
    dlg.showModal();
  }

  /* ---------- events ---------- */
  root.addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, msg = (id, html) => { const el = $(id); if (el) el.innerHTML = html; };
    try {
      if (f.id === 'loginForm') {
        const r = await api('POST', '/api/login', { username: f.username.value.trim(), password: f.password.value });
        S.user = r.username; S.csrf = r.csrf; f.password.value = '';
        if (r.mustChange) return showChange(true);
        return start();
      }
      if (f.id === 'changeForm' || f.id === 'accForm') {
        const box = f.id === 'changeForm' ? '#changeMsg' : '#accMsg';
        if (f.next.value !== f.again.value) return msg(box, '<div class="notice err">The new passwords do not match.</div>');
        await api('POST', '/api/password', { current: f.current.value, next: f.next.value });
        if (f.id === 'changeForm') return start();
        f.reset(); return msg(box, '<div class="notice ok">Password updated. Other sessions were signed out.</div>');
      }
      if (f.id === 'pform') {
        const fd = new FormData(f), id = f.dataset.id;
        const body = {
          name: fd.get('name'), brand: fd.get('brand'), model: fd.get('model'), category: fd.get('category'),
          price: fd.get('price'), oldPrice: fd.get('oldPrice') === '' ? null : fd.get('oldPrice'), stock: fd.get('stock'),
          popularity: fd.get('popularity') || 0, added: fd.get('added'), tags: fd.getAll('tag'),
          specs: String(fd.get('specs')).split('\n').map(s => s.trim()).filter(Boolean), active: fd.get('active') === 'on'
        };
        await api(id ? 'PUT' : 'POST', id ? '/api/products/' + id : '/api/products', body);
        $('#pdlg').close(); go('products');
      }
    } catch (err) {
      const target = { loginForm: '#loginMsg', changeForm: '#changeMsg', accForm: '#accMsg', pform: '#pmsg' }[f.id];
      if (target) msg(target, `<div class="notice err">${esc(err.message)}</div>`);
    }
  });

  root.addEventListener('input', e => { if (e.target.id === 'pq') drawProducts(e.target.value); });

  root.addEventListener('click', async e => {
    const nav = e.target.closest('[data-view]'); if (nav) return go(nav.dataset.view);
    const b = e.target.closest('[data-act]'); if (!b) return;
    const id = b.dataset.id;
    try {
      switch (b.dataset.act) {
        case 'logout': await api('POST', '/api/logout', {}); S.user = null; showLogin(); break;
        case 'new-product': openEditor(null); break;
        case 'edit-product': openEditor(S.products.find(p => p.id === Number(id))); break;
        case 'close-dialog': $('#pdlg').close(); break;
        case 'del-product': {
          const p = S.products.find(x => x.id === Number(id));
          if (confirm(`Delete "${p.name}"? This cannot be undone.`)) { await api('DELETE', '/api/products/' + id); go('products'); }
          break;
        }
        case 'set-status': await api('POST', `/api/orders/${id}/status`, { status: $('#st_' + id).value }); go('orders'); break;
        case 'read-msg': await api('POST', `/api/messages/${id}/read`, {}); go('messages'); break;
        case 'del-msg': if (confirm('Delete this message?')) { await api('DELETE', '/api/messages/' + id); go('messages'); } break;
      }
    } catch (err) { if (err.status !== 401 && err.status !== 403) alert(err.message); }
  });

  /* ---------- boot ---------- */
  function start() { shell(); go('dashboard'); }
  (async function init() {
    try {
      const r = await api('GET', '/api/session');
      S.user = r.username; S.csrf = r.csrf;
      if (r.mustChange) showChange(true); else start();
    } catch (e) { showLogin(); }
  })();
})();