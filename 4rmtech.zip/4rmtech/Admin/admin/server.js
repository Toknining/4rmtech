'use strict';
/* 4RMTECH admin server.
   - Admin UI + API:   http://127.0.0.1:4000   (login required, localhost only by default)
   - Public API for the storefront (products, contact form, order requests): /public/*
   Database: PostgreSQL when DATABASE_URL is set, otherwise SQLite (see lib/db.js). */
require('./lib/env');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { db, init, categories, ALLOWED_TAGS, ORDER_STATUSES } = require('./lib/db');
const auth = require('./lib/auth');

const PORT = Number(process.env.PORT) || 4000;
const HOST = process.env.HOST || '127.0.0.1';
const SECURE = process.env.SECURE_COOKIES === '1';
const PUBLIC_DIR = path.join(__dirname, 'public');
const list = v => String(v || '').split(',').map(s => s.trim()).filter(Boolean);

const allowedHosts = new Set(['localhost', '127.0.0.1', '[::1]', ...list(process.env.ALLOWED_HOSTS)]);
const ownOrigins = new Set();
for (const h of allowedHosts) { ownOrigins.add(`http://${h}:${PORT}`); ownOrigins.add(`https://${h}`); ownOrigins.add(`http://${h}`); }
const extraPublicOrigins = list(process.env.PUBLIC_ORIGINS);
const publicOriginOk = o => o === 'null' || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o) || extraPublicOrigins.includes(o);

/* ---------- small helpers ---------- */
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, msg) => { throw new HttpError(status, msg); };
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const money = n => Math.round(Number(n) * 100) / 100;

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(body));
}
async function readJson(req, limit = 64 * 1024) {
  if (!String(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) fail(415, 'JSON required');
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > limit) fail(413, 'Request too large'); chunks.push(c); }
  try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); return v && typeof v === 'object' ? v : {}; }
  catch (e) { fail(400, 'Invalid JSON'); }
}
const clientIp = req => {
  const a = req.socket.remoteAddress || '';
  // behind the local store server (npm start) the real visitor address arrives in X-Forwarded-For; only trusted from this computer
  if ((a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1') && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim().slice(0, 64);
  return a;
};
const safeEqual = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

function securityHeaders(res) {
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  if (SECURE) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}

/* ---------- rate limiting (in memory) ---------- */
const buckets = new Map();
function allow(key, limit, windowMs) {
  const now = Date.now(); let b = buckets.get(key);
  if (!b || b.reset < now) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
  return ++b.n <= limit;
}
const failures = new Map(); // login failures per ip+username
const lockedFor = key => { const f = failures.get(key); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 60000) : 0; };
function noteFailure(key) {
  const f = failures.get(key) || { n: 0, until: 0 };
  f.n += 1; if (f.n >= 5) { f.until = Date.now() + 15 * 60 * 1000; f.n = 0; }
  failures.set(key, f);
}
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k);
  for (const [k, f] of failures) if (f.until < now && f.n === 0) failures.delete(k);
  auth.purgeSessions().catch(() => {});
}, 10 * 60 * 1000).unref();

const audit = (ses, action, detail, req) =>
  db.run('INSERT INTO audit (admin, action, detail, ip) VALUES (?, ?, ?, ?)',
    [ses ? ses.username : '-', action, String(detail || '').slice(0, 300), clientIp(req)]);

/* ---------- products ---------- */
const toProduct = r => ({
  id: Number(r.id), name: r.name, brand: r.brand, model: r.model, category: r.category, price: Number(r.price),
  oldPrice: r.old_price === null || r.old_price === undefined ? null : Number(r.old_price),
  stock: Number(r.stock), popularity: Number(r.popularity), added: r.added,
  tags: JSON.parse(r.tags), specs: JSON.parse(r.specs), active: !!Number(r.active)
});
function cleanProduct(b) {
  const str = (v, min, max, label) => {
    const s = typeof v === 'string' ? v.trim() : '';
    if (s.length < min || s.length > max) fail(400, `${label} must be ${min}-${max} characters`);
    return s;
  };
  const num = (v, min, max, label, int) => {
    const n = Number(v);
    if (!Number.isFinite(n) || n < min || n > max || (int && !Number.isInteger(n))) fail(400, `${label} must be ${int ? 'a whole number ' : 'a number '}between ${min} and ${max}`);
    return n;
  };
  const p = {
    name: str(b.name, 2, 120, 'Name'), brand: str(b.brand, 1, 60, 'Brand'),
    model: b.model ? str(b.model, 0, 60, 'Model') : '',
    category: String(b.category), price: num(b.price, 0, 10000000, 'Price'),
    oldPrice: b.oldPrice === null || b.oldPrice === '' || b.oldPrice === undefined ? null : num(b.oldPrice, 0, 10000000, 'Original price'),
    stock: num(b.stock, 0, 100000, 'Stock', true), popularity: num(b.popularity ?? 0, 0, 100, 'Popularity', true),
    added: /^\d{4}-\d{2}-\d{2}$/.test(String(b.added)) ? String(b.added) : new Date().toISOString().slice(0, 10),
    tags: Array.isArray(b.tags) ? [...new Set(b.tags.map(String))] : [],
    specs: Array.isArray(b.specs) ? b.specs.map(s => String(s).trim()).filter(Boolean) : [],
    active: b.active === false ? 0 : 1
  };
  if (!categories.some(c => c.id === p.category)) fail(400, 'Unknown category');
  if (p.oldPrice !== null && p.oldPrice <= p.price) fail(400, 'Original price must be higher than the price');
  if (p.tags.some(t => !ALLOWED_TAGS.includes(t))) fail(400, 'Unknown tag');
  if (p.specs.length > 8 || p.specs.some(s => s.length > 100)) fail(400, 'Up to 8 specs, 100 characters each');
  return p;
}
const productParams = c => [c.name, c.brand, c.model, c.category, c.price, c.oldPrice, c.stock, c.popularity, c.added, JSON.stringify(c.tags), JSON.stringify(c.specs), c.active];

/* ---------- orders ---------- */
const qs = n => Array.from({ length: n }, () => '?').join(',');
async function ordersWithItems(rows) {
  const out = rows.map(r => ({ id: Number(r.id), customer: r.customer, email: r.email, phone: r.phone, address: r.address, city: r.city, zip: r.zip, total: Number(r.total), status: r.status, created_at: r.created_at, items: [] }));
  if (!out.length) return out;
  const items = await db.all(`SELECT order_id, product_id, name, unit_price, qty FROM order_items WHERE order_id IN (${qs(out.length)}) ORDER BY id`, out.map(o => o.id));
  const by = new Map(out.map(o => [o.id, o]));
  for (const i of items) by.get(Number(i.order_id))?.items.push({ product_id: Number(i.product_id), name: i.name, unit_price: Number(i.unit_price), qty: Number(i.qty) });
  return out;
}
const holdsStock = s => s === 'confirmed' || s === 'completed';

/* ---------- live updates (Server-Sent Events) ---------- */
// The storefront keeps one tiny read-only connection open. Whenever the catalogue changes we send
// "changed" and the storefront re-downloads the products. No data travels over this channel.
const liveClients = new Set();
const MAX_LIVE = 200;
let liveVersion = Date.now();
function broadcast() {
  liveVersion = Date.now();
  for (const r of liveClients) { try { r.write(`event: changed\ndata: ${liveVersion}\n\n`); } catch (e) { liveClients.delete(r); } }
}
setInterval(() => { for (const r of liveClients) { try { r.write(': ping\n\n'); } catch (e) { liveClients.delete(r); } } }, 25000).unref();

/* ---------- public API (for the storefront) ---------- */
async function publicRoutes(req, res, url) {
  const origin = req.headers.origin;
  const cors = origin && publicOriginOk(origin) ? { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin' } : {};
  if (req.method === 'OPTIONS') {
    return send(res, 204, {}, { ...cors, 'Access-Control-Allow-Methods': 'GET, POST', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '600' });
  }
  if (url.pathname === '/public/events' && req.method === 'GET') {
    if (liveClients.size >= MAX_LIVE) fail(503, 'Too many live connections');
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no', ...cors });
    res.write(`retry: 3000\nevent: hello\ndata: ${liveVersion}\n\n`);
    liveClients.add(res);
    req.on('close', () => liveClients.delete(res));
    return;
  }
  if (url.pathname === '/public/products' && req.method === 'GET') {
    const rows = (await db.all('SELECT * FROM products WHERE active = 1 ORDER BY id')).map(toProduct);
    rows.forEach(p => delete p.active);
    return send(res, 200, rows, { ...cors, 'Cache-Control': 'no-store' });
  }
  if (url.pathname === '/public/contact' && req.method === 'POST') {
    if (origin && !publicOriginOk(origin)) fail(403, 'Origin not allowed');
    if (!allow('contact:' + clientIp(req), 5, 10 * 60 * 1000)) fail(429, 'Too many messages, try again later');
    const b = await readJson(req, 16 * 1024);
    const name = String(b.name || '').trim(), email = String(b.email || '').trim();
    const subject = String(b.subject || '').trim().slice(0, 80), message = String(b.message || '').trim();
    if (name.length < 2 || name.length > 80) fail(400, 'Invalid name');
    if (!EMAIL.test(email) || email.length > 120) fail(400, 'Invalid email');
    if (message.length < 10 || message.length > 2000) fail(400, 'Message must be 10-2000 characters');
    await db.run('INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)', [name, email, subject, message]);
    return send(res, 201, { ok: true }, cors);
  }
  if (url.pathname === '/public/orders' && req.method === 'POST') {
    if (origin && !publicOriginOk(origin)) fail(403, 'Origin not allowed');
    if (!allow('order:' + clientIp(req), Number(process.env.ORDER_RATE_LIMIT) || 5, 10 * 60 * 1000)) fail(429, 'Too many orders, try again later');
    const b = await readJson(req, 32 * 1024), c = b.customer || {};
    const name = String(c.name || '').trim(), email = String(c.email || '').trim(), phone = String(c.phone || '').trim();
    const address = String(c.address || '').trim(), city = String(c.city || '').trim(), zip = String(c.zip || '').trim();
    if (name.length < 2 || name.length > 80) fail(400, 'Please enter your full name');
    if (!EMAIL.test(email) || email.length > 120) fail(400, 'Please enter a valid email');
    if (!/^[+\d][\d\s()-]{6,24}$/.test(phone)) fail(400, 'Please enter a valid phone number');
    if (address.length < 5 || address.length > 200) fail(400, 'Please enter your street address');
    if (city.length < 2 || city.length > 80 || zip.length > 20) fail(400, 'Please check your city and postal code');
    if (!Array.isArray(b.items) || !b.items.length || b.items.length > 50) fail(400, 'Your cart is empty');
    const want = new Map();
    for (const it of b.items) {
      const id = Number(it && it.id), qty = Number(it && it.qty);
      if (!Number.isInteger(id) || id < 1 || !Number.isInteger(qty) || qty < 1 || qty > 99) fail(400, 'Invalid cart item');
      want.set(id, (want.get(id) || 0) + qty);
    }
    const ids = [...want.keys()];
    const products = new Map((await db.all(`SELECT * FROM products WHERE active = 1 AND id IN (${qs(ids.length)})`, ids)).map(r => [Number(r.id), toProduct(r)]));
    let total = 0; const lines = [];
    for (const [id, qty] of want) {          // prices and stock always come from the database, never from the browser
      const p = products.get(id);
      if (!p) fail(409, 'An item in your cart is no longer available. Please refresh the page.');
      if (qty > p.stock) fail(409, p.stock ? `Only ${p.stock} of "${p.name}" in stock.` : `"${p.name}" is out of stock.`);
      total += p.price * qty; lines.push([p.id, p.name, p.price, qty]);
    }
    total = money(total);
    const order = await db.get('INSERT INTO orders (customer, email, phone, address, city, zip, total) VALUES (?,?,?,?,?,?,?) RETURNING id', [name, email, phone, address, city, zip, total]);
    try {
      await db.run(`INSERT INTO order_items (order_id, product_id, name, unit_price, qty) VALUES ${lines.map(() => '(?,?,?,?,?)').join(',')}`,
        lines.flatMap(l => [Number(order.id), l[0], l[1], l[2], l[3]]));
    } catch (e) { await db.run('DELETE FROM orders WHERE id = ?', [Number(order.id)]); throw e; }
    return send(res, 201, { ok: true, id: Number(order.id), total }, cors);
  }
  fail(404, 'Not found');
}

/* ---------- admin API ---------- */
async function apiRoutes(req, res, url) {
  const p = url.pathname, m = req.method;
  const unsafe = m !== 'GET' && m !== 'HEAD';
  const origin = req.headers.origin;
  if (unsafe && origin && !ownOrigins.has(origin)) fail(403, 'Bad origin');

  /* login (no session yet) */
  if (p === '/api/login' && m === 'POST') {
    const b = await readJson(req, 4096);
    const ip = clientIp(req), key = `${ip}|${String(b.username || '').toLowerCase()}`;
    if (!allow('login:' + ip, 30, 15 * 60 * 1000)) fail(429, 'Too many attempts, try again later');
    const mins = lockedFor(key);
    if (mins) fail(429, `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}.`);
    const row = await auth.checkLogin(String(b.username || '').slice(0, 64), String(b.password || '').slice(0, 256));
    if (!row) { noteFailure(key); await audit({ username: String(b.username || '').slice(0, 32) }, 'login_failed', '', req); fail(401, 'Invalid username or password'); }
    failures.delete(key);
    const { token, csrf } = await auth.createSession(Number(row.id));
    await audit({ username: row.username }, 'login', '', req);
    return send(res, 200, { username: row.username, csrf, mustChange: !!Number(row.must_change) },
      { 'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${auth.SESSION_TTL / 1000}${SECURE ? '; Secure' : ''}` });
  }

  const ses = await auth.sessionFrom(req);
  if (!ses) fail(401, 'Not signed in');
  if (unsafe && !safeEqual(req.headers['x-csrf-token'] || '', ses.csrf)) fail(403, 'Bad CSRF token');

  if (p === '/api/session' && m === 'GET') return send(res, 200, { username: ses.username, csrf: ses.csrf, mustChange: ses.mustChange });
  if (p === '/api/logout' && m === 'POST') {
    await auth.destroySession(ses.hash); await audit(ses, 'logout', '', req);
    return send(res, 200, { ok: true }, { 'Set-Cookie': `sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${SECURE ? '; Secure' : ''}` });
  }
  if (p === '/api/password' && m === 'POST') {
    const b = await readJson(req, 4096);
    const current = String(b.current || ''), next = String(b.next || '');
    const row = await db.get('SELECT pass_hash FROM admins WHERE id = ?', [ses.adminId]);
    if (!auth.verifyPassword(current, row.pass_hash)) fail(400, 'Current password is incorrect');
    if (next.length < 12 || next.length > 128) fail(400, 'New password must be 12-128 characters');
    if (next === current || next.toLowerCase() === ses.username.toLowerCase()) fail(400, 'Choose a different password');
    await auth.setPassword(ses.adminId, next, ses.hash);
    await audit(ses, 'password_changed', '', req);
    return send(res, 200, { ok: true });
  }
  if (ses.mustChange) fail(403, 'password_change_required');

  if (p === '/api/categories' && m === 'GET') return send(res, 200, { categories, tags: ALLOWED_TAGS, statuses: ORDER_STATUSES });
  if (p === '/api/dashboard' && m === 'GET') {
    const one = async sql => Number((await db.get(sql)).n);
    return send(res, 200, {
      products: await one('SELECT COUNT(*) AS n FROM products'),
      active: await one('SELECT COUNT(*) AS n FROM products WHERE active = 1'),
      lowStock: await one('SELECT COUNT(*) AS n FROM products WHERE stock > 0 AND stock <= 5'),
      outOfStock: await one('SELECT COUNT(*) AS n FROM products WHERE stock = 0'),
      unreadMessages: await one('SELECT COUNT(*) AS n FROM messages WHERE is_read = 0'),
      pendingOrders: await one("SELECT COUNT(*) AS n FROM orders WHERE status = 'pending'"),
      orders: await one('SELECT COUNT(*) AS n FROM orders'),
      database: db.kind
    });
  }

  /* products */
  if (p === '/api/products' && m === 'GET') return send(res, 200, (await db.all('SELECT * FROM products ORDER BY id DESC')).map(toProduct));
  if (p === '/api/products' && m === 'POST') {
    const c = cleanProduct(await readJson(req));
    const r = await db.get(`INSERT INTO products (name,brand,model,category,price,old_price,stock,popularity,added,tags,specs,active)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?) RETURNING id`, productParams(c));
    await audit(ses, 'product_created', c.name, req);
    broadcast();
    return send(res, 201, { id: Number(r.id) });
  }
  let mt = p.match(/^\/api\/products\/(\d+)$/);
  if (mt && m === 'PUT') {
    const c = cleanProduct(await readJson(req));
    const r = await db.run(`UPDATE products SET name=?,brand=?,model=?,category=?,price=?,old_price=?,stock=?,popularity=?,added=?,tags=?,specs=?,active=? WHERE id=?`,
      [...productParams(c), Number(mt[1])]);
    if (!r.changes) fail(404, 'Product not found');
    await audit(ses, 'product_updated', `#${mt[1]} ${c.name}`, req);
    broadcast();
    return send(res, 200, { ok: true });
  }
  if (mt && m === 'DELETE') {
    const r = await db.run('DELETE FROM products WHERE id = ?', [Number(mt[1])]);
    if (!r.changes) fail(404, 'Product not found');
    await audit(ses, 'product_deleted', `#${mt[1]}`, req);
    broadcast();
    return send(res, 200, { ok: true });
  }

  /* messages */
  if (p === '/api/messages' && m === 'GET') return send(res, 200, (await db.all('SELECT * FROM messages ORDER BY id DESC LIMIT 500')).map(r => ({ ...r, id: Number(r.id), is_read: !!Number(r.is_read) })));
  mt = p.match(/^\/api\/messages\/(\d+)(\/read)?$/);
  if (mt && mt[2] && m === 'POST') { await db.run('UPDATE messages SET is_read = 1 WHERE id = ?', [Number(mt[1])]); return send(res, 200, { ok: true }); }
  if (mt && !mt[2] && m === 'DELETE') { await db.run('DELETE FROM messages WHERE id = ?', [Number(mt[1])]); await audit(ses, 'message_deleted', `#${mt[1]}`, req); return send(res, 200, { ok: true }); }

  /* orders */
  if (p === '/api/orders' && m === 'GET') return send(res, 200, await ordersWithItems(await db.all('SELECT * FROM orders ORDER BY id DESC LIMIT 200')));
  mt = p.match(/^\/api\/orders\/(\d+)\/status$/);
  if (mt && m === 'POST') {
    const b = await readJson(req, 1024), id = Number(mt[1]);
    if (!ORDER_STATUSES.includes(b.status)) fail(400, 'Unknown status');
    const order = await db.get('SELECT id, status FROM orders WHERE id = ?', [id]);
    if (!order) fail(404, 'Order not found');
    const items = await db.all('SELECT product_id, name, qty FROM order_items WHERE order_id = ?', [id]);
    if (!holdsStock(order.status) && holdsStock(b.status)) {            // confirming: take the items out of stock
      for (const it of items) {
        const pr = await db.get('SELECT stock FROM products WHERE id = ?', [Number(it.product_id)]);
        if (pr && Number(pr.stock) < Number(it.qty)) fail(409, `Not enough stock for "${it.name}" (${pr.stock} left, ${it.qty} needed)`);
      }
      for (const it of items) await db.run('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?', [Number(it.qty), Number(it.product_id), Number(it.qty)]);
    } else if (holdsStock(order.status) && !holdsStock(b.status)) {     // cancelling: put them back
      for (const it of items) await db.run('UPDATE products SET stock = stock + ? WHERE id = ?', [Number(it.qty), Number(it.product_id)]);
    }
    await db.run('UPDATE orders SET status = ? WHERE id = ?', [b.status, id]);
    await audit(ses, 'order_status', `#${id} ${order.status} -> ${b.status}`, req);
    broadcast();                                                        // stock may have changed
    return send(res, 200, { ok: true });
  }
  if (p === '/api/audit' && m === 'GET') return send(res, 200, (await db.all('SELECT * FROM audit ORDER BY id DESC LIMIT 150')).map(r => ({ ...r, id: Number(r.id) })));

  fail(404, 'Not found');
}

/* ---------- static admin UI (only files inside /public) ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') fail(405, 'Method not allowed');
  let rel; try { rel = decodeURIComponent(url.pathname); } catch (e) { fail(400, 'Bad path'); }
  if (rel === '/') rel = '/index.html';
  const file = path.resolve(PUBLIC_DIR, '.' + rel);
  if (file !== PUBLIC_DIR && !file.startsWith(PUBLIC_DIR + path.sep)) fail(403, 'Forbidden');
  let data; try { data = fs.readFileSync(file); } catch (e) { fail(404, 'Not found'); }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  res.end(req.method === 'HEAD' ? undefined : data);
}

/* ---------- server ---------- */
const server = http.createServer(async (req, res) => {
  try {
    securityHeaders(res);
    const host = String(req.headers.host || '').replace(/:\d+$/, '').toLowerCase();
    if (!allowedHosts.has(host)) fail(421, 'Misdirected request'); // blocks DNS-rebinding
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/public/')) return await publicRoutes(req, res, url);
    if (url.pathname.startsWith('/api/')) return await apiRoutes(req, res, url);
    return serveStatic(req, res, url);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    console.error(e);
    return send(res, 500, { error: 'Server error' });
  }
});
server.requestTimeout = 15000;
server.headersTimeout = 10000;

(async () => {
  await init();
  const created = await auth.ensureBuiltInAdmin();
  server.listen(PORT, HOST, () => {
    console.log(`\n  4RMTECH admin running at http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
    console.log(`  Database: ${db.kind === 'postgres' ? 'PostgreSQL' : 'SQLite (admin/data/store.db)'}`);
    if (created) {
      const pw = created.fromEnv ? '(the ADMIN_INITIAL_PASSWORD from your .env)' : created.password;
      const lines = [
        'Built-in admin account created (shown ONCE - save it now):', '',
        '  Username : ' + created.username, '  Password : ' + pw, '',
        'You must choose a new password at first login.', 'Lost it?  run:  npm run reset-admin'
      ];
      const w = Math.max(...lines.map(l => l.length)) + 2;
      console.log('\n  +' + '-'.repeat(w) + '+');
      for (const l of lines) console.log('  | ' + l.padEnd(w - 1) + '|');
      console.log('  +' + '-'.repeat(w) + '+');
    }
    console.log('');
  });
})().catch(e => {
  console.error('\n  Could not start: ' + e.message + (db.kind === 'postgres' ? '\n  Check DATABASE_URL, that PostgreSQL is running, and the user/password/database name.' : '') + '\n');
  process.exit(1);
});