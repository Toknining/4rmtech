/* 4RMTECH storefront – vanilla JS single-page app (hash routing).
   Data lives in js/data.js; talk to a backend through window.API. */
(function () {
  "use strict";

  const SITE = window.SITE, CATS = window.CATEGORIES, API = window.API;
  let PRODUCTS = window.PRODUCTS.slice();
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const app = $("#app");
  const peso = n => "₱" + Number(n).toLocaleString("en-PH", { maximumFractionDigits: 0 });
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const catName = id => (CATS.find(c => c.id === id) || {}).name || id;
  const byId = id => PRODUCTS.find(p => p.id === Number(id));

  /* ---------- storage ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem("4rm_" + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("4rm_" + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
  };
  const state = {
    cart: store.get("cart", []).filter(i => i && byId(i.id) && i.qty > 0),
    wish: store.get("wish", []).filter(id => byId(id)),
    user: store.get("user", null),
    shop: { q: "", cat: "all", brands: [], max: 0, sort: "popular", offerOnly: false }
  };
  const save = () => { store.set("cart", state.cart); store.set("wish", state.wish); store.set("user", state.user); };

  /* ---------- cart logic ---------- */
  const cart = {
    add(id, qty = 1) {
      const p = byId(id); if (!p || p.stock < 1) return false;
      const line = state.cart.find(i => i.id === p.id);
      if (line) line.qty = Math.min(p.stock, line.qty + qty); else state.cart.push({ id: p.id, qty: Math.min(p.stock, qty) });
      save(); updateBadges(); return true;
    },
    setQty(id, qty) {
      const p = byId(id), line = state.cart.find(i => i.id === Number(id));
      if (!line || !p) return;
      if (qty < 1) return cart.remove(id);
      line.qty = Math.min(p.stock, qty); save(); updateBadges();
    },
    remove(id) { state.cart = state.cart.filter(i => i.id !== Number(id)); save(); updateBadges(); },
    count() { return state.cart.reduce((n, i) => n + i.qty, 0); },
    subtotal() { return state.cart.reduce((s, i) => s + byId(i.id).price * i.qty, 0); },
    savings() { return state.cart.reduce((s, i) => { const p = byId(i.id); return s + (p.oldPrice ? (p.oldPrice - p.price) * i.qty : 0); }, 0); }
  };
  const toggleWish = id => {
    id = Number(id);
    state.wish = state.wish.includes(id) ? state.wish.filter(w => w !== id) : state.wish.concat(id);
    save(); updateBadges();
    return state.wish.includes(id);
  };

  /* ---------- UI helpers ---------- */
  let toastTimer;
  function toast(msg) {
    const t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
  }
  function updateBadges() {
    $("#cartCount").textContent = cart.count();
    const w = $("#wishCount"); w.textContent = state.wish.length; w.hidden = state.wish.length === 0;
    $("#accountBtn").textContent = state.user ? state.user.name.split(" ")[0] : "Account";
  }

  /* ---------- artwork (drawn in code, no image files) ---------- */
  let gid = 0;
  const ICONS = {
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    wrench: '<path d="M14.7 6.3a4 4 0 0 0-5 5L3 18l3 3 6.7-6.7a4 4 0 0 0 5-5l-2.4 2.4-2.6-.6-.6-2.6z"/>',
    headset: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>',
    network: '<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="M12 7.5V13M12 13l-6 4M12 13l6 4"/>',
    code: '<path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/>',
    briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
    shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
    star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    handshake: '<path d="m3 11 4-4 4 2 4-2 6 5-5 6-3-2-3 2-6-5z"/>'
  };
  const icon = (n, s = 24) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ICONS.chip}</svg>`;

  function art(cat) {
    const g = "ag" + (++gid);
    const defs = `<defs><linearGradient id="${g}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#27e0ff"/><stop offset="1" stop-color="#cddc2e"/></linearGradient></defs>`;
    const F = `fill="#0d1730" stroke="url(#${g})" stroke-width="2.5"`;
    const S = `fill="url(#${g})"`;
    const shapes = {
      laptops: `<rect x="40" y="26" width="120" height="76" rx="7" ${F}/><rect x="49" y="35" width="102" height="58" rx="3" fill="#162a54"/><path d="M24 108h152l-8 14H32z" ${F}/><path d="M60 80l20-22 18 14 22-26 20 22" fill="none" stroke="url(#${g})" stroke-width="2" opacity=".7"/>`,
      components: `<rect x="22" y="40" width="156" height="70" rx="8" ${F}/><circle cx="68" cy="75" r="24" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><circle cx="68" cy="75" r="5" ${S}/><circle cx="132" cy="75" r="24" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><circle cx="132" cy="75" r="5" ${S}/><rect x="30" y="110" width="110" height="9" rx="2" ${S} opacity=".8"/>`,
      monitors: `<rect x="26" y="20" width="148" height="92" rx="8" ${F}/><rect x="35" y="29" width="130" height="74" rx="3" fill="#162a54"/><path d="M45 92l28-30 24 18 28-34 30 28" fill="none" stroke="url(#${g})" stroke-width="2.5"/><path d="M88 112h24l4 18H84z" ${S} opacity=".7"/><rect x="66" y="130" width="68" height="6" rx="3" ${S}/>`,
      networking: `<rect x="24" y="78" width="152" height="40" rx="8" ${F}/><path d="M50 78 38 30M100 78V24M150 78l12-48" stroke="url(#${g})" stroke-width="5" stroke-linecap="round"/><circle cx="52" cy="98" r="4" ${S}/><circle cx="68" cy="98" r="4" ${S}/><circle cx="84" cy="98" r="4" ${S}/><rect x="112" y="94" width="50" height="8" rx="3" fill="#162a54"/>`,
      accessories: `<rect x="16" y="52" width="168" height="62" rx="9" ${F}/>${Array.from({ length: 3 }, (_, r) => Array.from({ length: 10 }, (_, c) => `<rect x="${26 + c * 15.4}" y="${62 + r * 15}" width="11" height="10" rx="2" fill="#162a54"/>`).join("")).join("")}<rect x="56" y="100" width="88" height="9" rx="3" ${S} opacity=".8"/>`,
      storage: `<rect x="30" y="38" width="140" height="74" rx="9" ${F}/><rect x="46" y="54" width="48" height="42" rx="5" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><rect x="104" y="54" width="48" height="16" rx="4" ${S} opacity=".85"/><rect x="104" y="78" width="48" height="18" rx="4" fill="#162a54"/>`,
      printers: `<rect x="56" y="22" width="88" height="34" rx="3" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><rect x="26" y="52" width="148" height="56" rx="9" ${F}/><rect x="52" y="86" width="96" height="42" rx="3" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><circle cx="150" cy="70" r="4" ${S}/><path d="M64 98h72M64 108h50" stroke="url(#${g})" stroke-width="2.5"/>`,
      power: `<rect x="28" y="40" width="144" height="70" rx="10" ${F}/><circle cx="64" cy="75" r="11" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><circle cx="100" cy="75" r="11" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><circle cx="136" cy="75" r="11" fill="#162a54" stroke="url(#${g})" stroke-width="2"/><path d="M104 22 94 40h10l-6 16 16-20h-10z" ${S}/>`
    };
    return `<svg viewBox="0 0 200 150" role="img" aria-label="${esc(catName(cat))} illustration" xmlns="http://www.w3.org/2000/svg">${defs}${shapes[cat] || shapes.laptops}</svg>`;
  }


  /* ---------- wordmark (drawn as SVG shapes, no image file) ---------- */
  function logoSvg() {
    const L = ["M80 20 50 70H98M80 36V100",
      "M0 100V24H40L50 34V52L40 62H0M20 62 54 100",
      "M0 100V24L30 62 60 24V100",
      "M0 24H60M30 24V100",
      "M42 24H0V100H42M0 62H38",
      "M42 24H0V100H42",
      "M0 24V100M52 24V100M0 62H52"];
    const X = [0, 119, 191, 268, 326, 385, 442];
    const paths = (w, c) => L.map((d, i) => `<path d="${d}" transform="translate(${X[i]} 0)" stroke="${c}" stroke-width="${w}"/>`).join("");
    return `<svg class="logo" viewBox="-8 4 514 112" role="img" aria-label="4RMTECH" xmlns="http://www.w3.org/2000/svg" fill="none" stroke-linejoin="miter" stroke-miterlimit="4">
      <polygon points="-2,100 30,28 52,28 20,100" fill="#fff"/>
      <g stroke-linecap="butt">${paths(26, "#06154a")}${paths(15, "#cddc2e")}</g></svg>`;
  }

  /* ---------- product components ---------- */
  const tagLabel = p => p.oldPrice ? "Offer" : p.tags.includes("new") ? "New" : p.tags.includes("bestseller") ? "Best Seller" : "";
  const stockInfo = p => { const d = API.live ? "" : " · demo"; return p.stock < 1 ? ["out", "Out of stock"] : p.stock <= 8 ? ["low", `Low stock (${p.stock} left)${d}`] : ["in", `In stock (${p.stock})${d}`]; };
  const ratingHtml = p => p.rating ? `<div class="rating">★ ${p.rating} (${p.reviews} reviews)</div>` : `<div class="rating">No reviews yet</div>`;
  const priceHtml = p => `<div class="price"><b>${peso(p.price)}</b>${p.oldPrice ? `<s>${peso(p.oldPrice)}</s><span class="off">-${Math.round((1 - p.price / p.oldPrice) * 100)}%</span>` : ""}</div>`;
  const heartSvg = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>';

  function card(p) {
    const [cls, label] = stockInfo(p), tl = tagLabel(p), wished = state.wish.includes(p.id);
    return `<article class="card">
      ${tl ? `<span class="tag">${tl}</span>` : ""}
      <button class="wish" data-wish="${p.id}" aria-pressed="${wished}" aria-label="${wished ? "Remove from" : "Add to"} wishlist: ${esc(p.name)}">${heartSvg}</button>
      <a class="thumb" href="#/product/${p.id}" aria-label="View ${esc(p.name)}">${art(p.category)}</a>
      <div class="body">
        <span class="brandline">${esc(p.brand)}</span>
        <h3><a href="#/product/${p.id}">${esc(p.name)}</a></h3>
        <span class="model">Model: ${esc(p.model)}</span>
        ${priceHtml(p)}
        <span class="stock ${cls}">${label}</span>
        ${ratingHtml(p)}
        <div class="actions">
          <a class="btn btn-ghost" href="#/product/${p.id}">View Details</a>
          <button class="btn btn-primary" data-add="${p.id}" ${p.stock < 1 ? "disabled" : ""}>Add to Cart</button>
        </div>
      </div>
    </article>`;
  }

  /* ---------- views ---------- */
  const TABS = [
    ["featured", "Featured Products", p => p.tags.includes("featured")],
    ["bestseller", "Best Sellers", p => p.tags.includes("bestseller")],
    ["new", "New Arrivals", p => p.tags.includes("new")],
    ["recommended", "Recommended", p => p.tags.includes("recommended")],
    ["offer", "Special Offers", p => !!p.oldPrice]
  ];
  let homeTab = "featured";

  function homeView() {
    const heroCats = ["laptops", "monitors", "networking", "components"];
    return `
    <section class="hero" id="home"><div class="container hero-grid">
      <div>
        <span class="pill"><i></i> Technology, hardware &amp; IT solutions</span>
        <h1>Powering Your <span class="grad-text">Digital World.</span></h1>
        <p class="lead">Discover reliable technology, powerful hardware, and innovative solutions designed for work, business, and everyday life.</p>
        <div class="hero-cta">
          <a class="btn btn-primary" href="#/shop">Shop Now</a>
          <a class="btn btn-ghost" href="#/" data-scroll="products">Explore Products</a>
        </div>
        <div class="hero-stats">
          <div><b>${PRODUCTS.length} products</b><span>${API.live ? "In our catalog" : "Sample catalog"}</span></div>
          <div><b>${CATS.length} categories</b><span>Hardware to power</span></div>
          <div><b>IT services</b><span>Setup &amp; support</span></div>
        </div>
      </div>
      <div class="hero-visual" aria-hidden="true">
        ${heroCats.map((c, i) => `<div class="float f${i + 1}">${art(c)}</div>`).join("")}
      </div>
    </div></section>

    <section id="categories"><div class="container">
      <div class="section-head"><div><div class="eyebrow">Browse</div><h2>Shop by Category</h2><p>Everything from laptops and components to networking and power.</p></div></div>
      <div class="grid cat-grid">
        ${CATS.map(c => `<a class="cat-card" href="#/shop?cat=${c.id}"><div class="art">${art(c.id)}</div><h3>${esc(c.name)}</h3><p>${esc(c.desc)}</p><span class="go">Browse category →</span></a>`).join("")}
      </div>
    </div></section>

    <section class="alt" id="products"><div class="container">
      <div class="section-head"><div><div class="eyebrow">Store</div><h2>Our Products</h2><p>${API.live ? "Browse our current catalog." : "Sample products, prices and stock levels are demo data until your inventory is connected."}</p></div><a class="btn btn-ghost" href="#/shop">View all products</a></div>
      <div class="tabs" role="tablist" aria-label="Product groups">
        ${TABS.map(t => `<button class="tab" role="tab" data-tab="${t[0]}" aria-selected="${t[0] === homeTab}">${t[1]}</button>`).join("")}
      </div>
      <div class="grid prod-grid" id="homeGrid"></div>
    </div></section>

    <section id="why"><div class="container">
      <div class="section-head"><div><div class="eyebrow">Why us</div><h2>Why Choose 4RMTECH?</h2></div></div>
      <div class="grid feat-grid">
        ${[["star", "Quality Technology Products", "Carefully selected hardware and devices from established brands."],
          ["headset", "Reliable Technical Support", "Practical help before and after your purchase."],
          ["briefcase", "Professional IT Solutions", "Setup, networking and business technology services."],
          ["heart", "Customer-Focused Service", "Advice that fits your needs and budget."],
          ["handshake", "Trusted Technology Partner", "A long-term partner for your technology needs."]]
          .map(f => `<div class="feat"><div class="ico">${icon(f[0])}</div><h3>${f[1]}</h3><p>${f[2]}</p></div>`).join("")}
      </div>
    </div></section>

    <section class="alt" id="services"><div class="container">
      <div class="section-head"><div><div class="eyebrow">Services</div><h2>IT Services</h2><p>Edit the list in js/data.js to match what 4RMTECH actually offers.</p></div></div>
      <div class="grid srv-grid">
        ${window.SERVICES.map(s => `<div class="srv"><div class="ico">${icon(s.icon)}</div><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p><a class="more" href="#/" data-scroll="contact">Learn More →</a></div>`).join("")}
      </div>
    </div></section>

    <section><div class="container"><div class="promo">
      <div class="eyebrow">Special offers</div>
      <h2>Upgrade Your Technology. <span class="grad-text">Elevate Your Performance.</span></h2>
      <p>Browse discounted hardware, accessories and storage.${API.live ? "" : " Offers shown are demo prices."}</p>
      <a class="btn btn-primary" href="#/shop?offers=1">Discover Deals</a>
    </div></div></section>

    <section id="about"><div class="container">
      <div class="section-head"><div><div class="eyebrow">About</div><h2>About 4RMTECH</h2><p>${esc(SITE.about.overview)}</p></div></div>
      <div class="about-grid">
        <div class="info"><h3>Mission</h3><p>${esc(SITE.about.mission)}</p></div>
        <div class="info"><h3>Vision</h3><p>${esc(SITE.about.vision)}</p></div>
        <div class="info"><h3>Company History</h3><p>${esc(SITE.about.history)}</p></div>
        <div class="info"><h3>Business Location &amp; Contact</h3><p>${esc(SITE.about.location)} ${esc(SITE.about.contact)}</p></div>
      </div>
    </div></section>

    <section class="alt" id="contact"><div class="container">
      <div class="section-head"><div><div class="eyebrow">Support</div><h2>Contact &amp; Customer Support</h2></div></div>
      <div class="contact-grid">
        <form class="panel" id="contactForm" novalidate>
          <h3>Send us a message</h3>
          <div class="row2">
            <div class="field"><label for="cName">Name</label><input id="cName" name="name" autocomplete="name"><span class="err" data-for="name"></span></div>
            <div class="field"><label for="cEmail">Email</label><input id="cEmail" name="email" type="email" autocomplete="email"><span class="err" data-for="email"></span></div>
          </div>
          <div class="field"><label for="cSubject">Subject</label><select id="cSubject" name="subject"><option>Product inquiry</option><option>Order support</option><option>IT services</option><option>Other</option></select></div>
          <div class="field"><label for="cMsg">Message</label><textarea id="cMsg" name="message" rows="5"></textarea><span class="err" data-for="message"></span></div>
          <button class="btn btn-primary" type="submit">Send Message</button>
          <div id="contactResult" aria-live="polite"></div>
        </form>
        <div>
          <div class="panel">
            <h3>Customer Support</h3>
            <ul class="contact-list">
              <li><b>Email</b>${esc(SITE.email)}</li>
              <li><b>Telephone</b>${esc(SITE.phone)}</li>
              <li><b>Address</b>${esc(SITE.address)}</li>
              <li><b>Hours</b>${esc(SITE.hours)}</li>
            </ul>
          </div>
          <div id="faq" style="margin-top:20px">
            <h3 style="margin-bottom:6px">Frequently Asked Questions</h3>
            ${window.FAQS.map(f => `<details><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`).join("")}
          </div>
        </div>
      </div>
    </div></section>`;
  }

  function mountHome() {
    const fill = () => {
      const t = TABS.find(x => x[0] === homeTab);
      $("#homeGrid").innerHTML = PRODUCTS.filter(t[2]).slice(0, 8).map(card).join("") || '<div class="empty">No products in this group.</div>';
    };
    fill();
    $$(".tab").forEach(b => b.addEventListener("click", () => {
      homeTab = b.dataset.tab;
      $$(".tab").forEach(x => x.setAttribute("aria-selected", x === b));
      fill();
    }));
    $("#contactForm").addEventListener("submit", onContact);
  }

  async function onContact(e) {
    e.preventDefault();
    const f = e.target, v = n => f.elements[n].value.trim(), errs = {};
    if (v("name").length < 2) errs.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v("email"))) errs.email = "Enter a valid email address.";
    if (v("message").length < 10) errs.message = "Message should be at least 10 characters.";
    $$(".err", f).forEach(s => { s.textContent = errs[s.dataset.for] || ""; s.parentElement.classList.toggle("invalid", !!errs[s.dataset.for]); });
    const out = $("#contactResult");
    if (Object.keys(errs).length) { out.innerHTML = '<div class="notice err">Please fix the highlighted fields.</div>'; return; }
    if (typeof API.submitContact === "function") {
      try { await API.submitContact({ name: v("name"), email: v("email"), subject: v("subject"), message: v("message") }); out.innerHTML = '<div class="notice ok">Thank you! Your message has been sent.</div>'; f.reset(); }
      catch (err) { out.innerHTML = `<div class="notice err">${esc(err.message || "Sorry, your message could not be sent. Please try again.")}</div>`; }
    } else {
      out.innerHTML = '<div class="notice info">Your details look valid, but this demo is not connected to a backend, so the message was <b>not</b> sent. Set <code>SITE.apiBase</code> in js/data.js to enable delivery.</div>';
    }
  }

  /* ----- shop ----- */
  function filtered() {
    const s = state.shop, q = s.q.toLowerCase();
    let list = PRODUCTS.filter(p =>
      (s.cat === "all" || p.category === s.cat) &&
      (!s.brands.length || s.brands.includes(p.brand)) &&
      (!s.max || p.price <= s.max) &&
      (!s.offerOnly || p.oldPrice) &&
      (!q || [p.name, p.brand, p.model, catName(p.category)].join(" ").toLowerCase().includes(q)));
    const sorters = {
      popular: (a, b) => b.popularity - a.popularity,
      newest: (a, b) => b.added.localeCompare(a.added),
      low: (a, b) => a.price - b.price,
      high: (a, b) => b.price - a.price
    };
    return list.sort(sorters[s.sort]);
  }

  function shopView() {
    const brands = Array.from(new Set(PRODUCTS.map(p => p.brand))).sort();
    const maxP = Math.ceil(Math.max(...PRODUCTS.map(p => p.price)) / 1000) * 1000;
    if (!state.shop.max) state.shop.max = maxP;
    const s = state.shop;
    return `<div class="page"><div class="container">
      
      <h1>Shop</h1>
      <div class="shop-layout">
        <aside class="filters" aria-label="Filters">
          <div class="group"><h3>Search</h3><input type="search" id="fQ" value="${esc(s.q)}" placeholder="Name, brand or model"></div>
          <div class="group"><h3>Category</h3><select id="fCat"><option value="all">All categories</option>${CATS.map(c => `<option value="${c.id}" ${s.cat === c.id ? "selected" : ""}>${esc(c.name)}</option>`).join("")}</select></div>
          <div class="group"><h3>Max price: <span id="fMaxLbl">${peso(s.max)}</span></h3><input type="range" id="fMax" min="500" max="${maxP}" step="500" value="${s.max}" aria-label="Maximum price"></div>
          <div class="group"><h3>Brand</h3>${brands.map(b => `<label class="chk"><input type="checkbox" class="fBrand" value="${esc(b)}" ${s.brands.includes(b) ? "checked" : ""}> ${esc(b)}</label>`).join("")}</div>
          <div class="group"><label class="chk"><input type="checkbox" id="fOffer" ${s.offerOnly ? "checked" : ""}> Special offers only</label></div>
          <button class="btn btn-ghost btn-block btn-sm" id="fReset">Reset filters</button>
        </aside>
        <div>
          <div class="toolbar"><span class="muted" id="resCount" aria-live="polite"></span>
            <label>Sort by <select id="fSort">${[["popular", "Popularity"], ["newest", "Newest"], ["low", "Price: low to high"], ["high", "Price: high to low"]].map(o => `<option value="${o[0]}" ${s.sort === o[0] ? "selected" : ""}>${o[1]}</option>`).join("")}</select></label>
          </div>
          <div class="grid prod-grid" id="shopGrid"></div>
        </div>
      </div></div></div>`;
  }

  function mountShop() {
    const s = state.shop;
    const draw = () => {
      const list = filtered();
      $("#resCount").textContent = `${list.length} product${list.length === 1 ? "" : "s"}`;
      $("#shopGrid").innerHTML = list.length ? list.map(card).join("") : '<div class="empty" style="grid-column:1/-1">No products match your filters.<br><button class="btn btn-ghost" id="emptyReset">Reset filters</button></div>';
      const r = $("#emptyReset"); if (r) r.addEventListener("click", reset);
    };
    const reset = () => { Object.assign(state.shop, { q: "", cat: "all", brands: [], max: 0, sort: "popular", offerOnly: false }); render(); };
    $("#fQ").addEventListener("input", e => { s.q = e.target.value; draw(); });
    $("#fCat").addEventListener("change", e => { s.cat = e.target.value; draw(); });
    $("#fMax").addEventListener("input", e => { s.max = Number(e.target.value); $("#fMaxLbl").textContent = peso(s.max); draw(); });
    $$(".fBrand").forEach(c => c.addEventListener("change", () => { s.brands = $$(".fBrand:checked").map(x => x.value); draw(); }));
    $("#fOffer").addEventListener("change", e => { s.offerOnly = e.target.checked; draw(); });
    $("#fSort").addEventListener("change", e => { s.sort = e.target.value; draw(); });
    $("#fReset").addEventListener("click", reset);
    draw();
  }

  /* ----- product detail ----- */
  function productView(id) {
    const p = byId(id);
    if (!p) return notFound();
    const [cls, label] = stockInfo(p);
    const related = PRODUCTS.filter(x => x.category === p.category && x.id !== p.id).slice(0, 4);
    return `<div class="page"><div class="container">
      
      <div class="detail">
        <div class="gallery">${art(p.category)}</div>
        <div>
          <span class="brandline">${esc(p.brand)}</span>
          <h1>${esc(p.name)}</h1>
          <span class="model">Model: ${esc(p.model)}</span>
          ${priceHtml(p)}
          <p class="stock ${cls}" style="margin-top:6px">${label}</p>
          ${ratingHtml(p)}
          <ul class="specs">${p.specs.map(x => `<li>${esc(x)}</li>`).join("")}</ul>
          ${API.live ? "" : '<p class="muted" style="font-size:.85rem">Demo listing: price, stock and specifications are placeholders until real inventory is supplied.</p>'}
          <div class="buy">
            <div class="qty"><button id="dMinus" aria-label="Decrease quantity">−</button><span id="dQty" aria-live="polite">1</span><button id="dPlus" aria-label="Increase quantity">+</button></div>
            <button class="btn btn-primary" id="dAdd" ${p.stock < 1 ? "disabled" : ""}>Add to Cart</button>
            <button class="btn btn-ghost" data-wish="${p.id}" aria-pressed="${state.wish.includes(p.id)}" id="dWish">${state.wish.includes(p.id) ? "♥ In wishlist" : "♡ Wishlist"}</button>
          </div>
        </div>
      </div>
      ${related.length ? `<h2 style="margin:56px 0 20px">Related products</h2><div class="grid prod-grid">${related.map(card).join("")}</div>` : ""}
    </div></div>`;
  }
  function mountProduct(id) {
    const p = byId(id); if (!p) return;
    let q = 1; const out = $("#dQty");
    $("#dMinus").addEventListener("click", () => { q = Math.max(1, q - 1); out.textContent = q; });
    $("#dPlus").addEventListener("click", () => { q = Math.min(p.stock || 1, q + 1); out.textContent = q; });
    $("#dAdd").addEventListener("click", () => { if (cart.add(p.id, q)) toast(`Added ${q} × ${p.name} to cart`); });
  }

  /* ----- cart drawer (slides in from the side) ----- */
  const drawer = $("#cartDrawer"), overlay = $("#overlay");
  let lastFocus = null;
  function renderDrawer() {
    const body = $("#drawerBody"), foot = $("#drawerFoot");
    if (!state.cart.length) {
      body.innerHTML = '<div class="empty">Your cart is empty.<br><a class="btn btn-primary" href="#/shop" data-close-cart>Start shopping</a></div>';
      foot.innerHTML = ""; foot.hidden = true; return;
    }
    foot.hidden = false;
    body.innerHTML = state.cart.map(i => { const p = byId(i.id); return `<div class="dline">
      <div class="t">${art(p.category)}</div>
      <div><span class="brandline">${esc(p.brand)}</span><h3><a href="#/product/${p.id}" data-close-cart>${esc(p.name)}</a></h3><span class="muted" style="font-size:.85rem">${peso(p.price)} each</span>
        <div class="ctl"><div class="qty"><button data-dec="${p.id}" aria-label="Decrease quantity of ${esc(p.name)}">−</button><span>${i.qty}</span><button data-inc="${p.id}" aria-label="Increase quantity of ${esc(p.name)}" ${i.qty >= p.stock ? "disabled" : ""}>+</button></div>
        <button class="link-btn" data-remove="${p.id}">Remove</button></div></div>
      <div class="lt">${peso(p.price * i.qty)}</div></div>`; }).join("");
    const sav = cart.savings();
    foot.innerHTML = `<div class="row"><span>Items</span><span>${cart.count()}</span></div>
      ${sav ? `<div class="row"><span>You save</span><span style="color:var(--ok)">${peso(sav)}</span></div>` : ""}
      <div class="row total"><span>Subtotal</span><span>${peso(cart.subtotal())}</span></div>
      <a class="btn btn-primary btn-block" href="#/checkout" data-close-cart>Proceed to Checkout</a>
      <button class="btn btn-ghost btn-block" data-close-cart>Continue Shopping</button>`;
  }
  function openCart() {
    lastFocus = document.activeElement;
    renderDrawer();
    overlay.hidden = false; drawer.classList.add("open"); drawer.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    $("#closeCart").focus();
  }
  function closeCart() {
    if (!drawer.classList.contains("open")) return;
    drawer.classList.remove("open"); drawer.setAttribute("aria-hidden", "true");
    overlay.hidden = true; document.body.style.overflow = "";
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  const refreshCart = () => { renderDrawer(); if (route().seg[0] === "checkout") render(); };

  function summary() {
    const sav = cart.savings();
    return `<aside class="panel summary"><h3>Order Summary</h3>
      <dl><dt>Items</dt><dd>${cart.count()}</dd><dt>Subtotal</dt><dd>${peso(cart.subtotal())}</dd>
      ${sav ? `<dt>You save</dt><dd style="color:var(--ok)">${peso(sav)}</dd>` : ""}
      <dt>Shipping</dt><dd class="muted">Set at checkout</dd></dl>
      <dl class="total"><dt>Subtotal</dt><dd>${peso(cart.subtotal())}</dd></dl>
    </aside>`;
  }

  /* ----- checkout ----- */
  function checkoutView() {
    if (!state.cart.length) return `<div class="page"><div class="container"><h1>Checkout</h1><div class="empty">Your cart is empty.<br><a class="btn btn-primary" href="#/shop">Browse products</a></div></div></div>`;
    const u = state.user || {};
    return `<div class="page"><div class="container">
      <h1>Checkout</h1>
      <div class="cart-layout">
        <form class="panel" id="coForm" novalidate>
          <h3>Contact &amp; Shipping</h3>
          <div class="row2">
            <div class="field"><label for="coName">Full name</label><input id="coName" name="name" value="${esc(u.name || "")}" autocomplete="name"><span class="err" data-for="name"></span></div>
            <div class="field"><label for="coEmail">Email</label><input id="coEmail" name="email" type="email" value="${esc(u.email || "")}" autocomplete="email"><span class="err" data-for="email"></span></div>
          </div>
          <div class="field"><label for="coPhone">Phone</label><input id="coPhone" name="phone" type="tel" autocomplete="tel"><span class="err" data-for="phone"></span></div>
          <div class="field"><label for="coAddr">Street address</label><input id="coAddr" name="address" autocomplete="street-address"><span class="err" data-for="address"></span></div>
          <div class="row2">
            <div class="field"><label for="coCity">City</label><input id="coCity" name="city" autocomplete="address-level2"><span class="err" data-for="city"></span></div>
            <div class="field"><label for="coZip">Postal code</label><input id="coZip" name="zip" autocomplete="postal-code"></div>
          </div>
          <h3 style="margin-top:8px">Payment</h3>
          <div class="pay-opts">
            <label><input type="radio" name="pay" checked> ${API.live ? "Payment is not collected on this website. After you submit, 4RMTECH will contact you to confirm your order and arrange payment and delivery." : "Payment methods will appear here once a payment gateway is connected"}</label>
          </div>
          <button class="btn btn-primary btn-block" type="submit">${API.live ? "Submit Order Request" : "Place Order"}</button>
          <div id="coResult" aria-live="polite"></div>
        </form>
        <div>${summary(false)}</div>
      </div></div></div>`;
  }
  function mountCheckout() {
    const f = $("#coForm"); if (!f) return;
    f.addEventListener("submit", async e => {
      e.preventDefault();
      const v = n => f.elements[n].value.trim(), errs = {};
      if (v("name").length < 2) errs.name = "Enter your full name.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v("email"))) errs.email = "Enter a valid email.";
      if (!/^[+\d][\d\s()-]{6,}$/.test(v("phone"))) errs.phone = "Enter a valid phone number.";
      if (v("address").length < 5) errs.address = "Enter your street address.";
      if (v("city").length < 2) errs.city = "Enter your city.";
      $$(".err", f).forEach(s => { s.textContent = errs[s.dataset.for] || ""; s.parentElement.classList.toggle("invalid", !!errs[s.dataset.for]); });
      const out = $("#coResult");
      if (Object.keys(errs).length) { out.innerHTML = '<div class="notice err">Please fix the highlighted fields.</div>'; return; }
      if (API.live && typeof API.placeOrder === "function") {
        const btn = f.querySelector("button[type=submit]"); btn.disabled = true;
        try {
          const r = await API.placeOrder(state.cart.map(i => ({ id: i.id, qty: i.qty })), { name: v("name"), email: v("email"), phone: v("phone"), address: v("address"), city: v("city"), zip: v("zip") });
          state.cart = []; save(); updateBadges();
          out.innerHTML = `<div class="notice ok"><b>Order request #${esc(r.id)} received</b> (total ${peso(r.total)}). No payment has been taken online. 4RMTECH will contact you to confirm your order and arrange payment and delivery.</div>`;
        } catch (err) {
          btn.disabled = false;
          out.innerHTML = `<div class="notice err">${esc(err.message || "The order could not be sent. Please try again.")}</div>`;
        }
      } else {
        out.innerHTML = SITE.apiBase
          ? '<div class="notice err">The store server could not be reached, so <b>no order was placed</b> and you have not been charged. Please try again in a moment.</div>'
          : '<div class="notice info">Your details look valid, but checkout is not connected to a payment gateway or order backend, so <b>no order was placed</b> and you have not been charged. Set <code>SITE.apiBase</code> in js/data.js to enable ordering.</div>';
      }
    });
  }

  /* ----- wishlist ----- */
  function wishlistView() {
    const items = state.wish.map(byId).filter(Boolean);
    return `<div class="page"><div class="container"><h1>Your Wishlist</h1>
      ${items.length ? `<div class="grid prod-grid">${items.map(card).join("")}</div>` : '<div class="empty">Your wishlist is empty.<br><a class="btn btn-primary" href="#/shop">Browse products</a></div>'}
    </div></div>`;
  }

  /* ----- account ----- */
  function accountView() {
    const u = state.user;
    if (!u) return `<div class="page"><div class="container"><h1>Account</h1>
      <div class="contact-grid">
        <form class="panel" id="loginForm" novalidate>
          <h3>Sign in / Create account</h3>
          <div class="field"><label for="aName">Full name</label><input id="aName" name="name" autocomplete="name"><span class="err" data-for="name"></span></div>
          <div class="field"><label for="aEmail">Email</label><input id="aEmail" name="email" type="email" autocomplete="email"><span class="err" data-for="email"></span></div>
          <div class="field"><label for="aPass">Password</label><input id="aPass" name="password" type="password" autocomplete="current-password"><span class="err" data-for="password"></span></div>
          <button class="btn btn-primary" type="submit">Continue</button>
          <div class="notice info">Demo only: no real authentication is connected. Your name and email are saved in this browser, and the password is not stored or checked.</div>
        </form>
        <div class="panel"><h3>With an account you can</h3><ul class="specs"><li>View order history</li><li>Save shipping details</li><li>Manage your wishlist</li></ul></div>
      </div></div></div>`;
    return `<div class="page"><div class="container"><h1>My Account</h1>
      <div class="contact-grid">
        <div class="panel"><h3>Profile</h3>
          <ul class="contact-list"><li><b>Name</b>${esc(u.name)}</li><li><b>Email</b>${esc(u.email)}</li></ul>
          <div class="buy"><a class="btn btn-ghost" href="#/wishlist">View wishlist (${state.wish.length})</a><button class="btn btn-ghost" id="logout">Sign out</button></div>
        </div>
        <div class="panel"><h3>Order History</h3><div id="orders" class="muted">Loading…</div></div>
      </div></div></div>`;
  }
  async function mountAccount() {
    const lf = $("#loginForm");
    if (lf) lf.addEventListener("submit", async e => {
      e.preventDefault();
      const v = n => lf.elements[n].value.trim(), errs = {};
      if (v("name").length < 2) errs.name = "Enter your name.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v("email"))) errs.email = "Enter a valid email.";
      if (v("password").length < 6) errs.password = "Use at least 6 characters.";
      $$(".err", lf).forEach(s => { s.textContent = errs[s.dataset.for] || ""; s.parentElement.classList.toggle("invalid", !!errs[s.dataset.for]); });
      if (Object.keys(errs).length) return;
      state.user = await API.login({ name: v("name"), email: v("email") });
      save(); updateBadges(); render();
    });
    const lo = $("#logout"); if (lo) lo.addEventListener("click", () => { state.user = null; save(); updateBadges(); render(); });
    const box = $("#orders");
    if (box) {
      const orders = await API.getOrders(state.user);
      box.innerHTML = orders.length
        ? `<div class="table-wrap"><table><thead><tr><th>Order</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th></tr></thead><tbody>${orders.map(o => `<tr><td>${esc(o.id)}</td><td>${esc(o.date)}</td><td>${esc(o.items)}</td><td>${peso(o.total)}</td><td>${esc(o.status)}</td></tr>`).join("")}</tbody></table></div>`
        : "No orders yet. Orders will appear here once checkout is connected to a backend.";
    }
  }

  /* ----- policies / 404 ----- */
  function policyView(kind) {
    const T = { privacy: "Privacy Policy", terms: "Terms and Conditions", returns: "Return and Refund Policy" };
    if (!T[kind]) return notFound();
    return `<div class="page"><div class="container policy"><h1>${T[kind]}</h1>
      <p>This is a placeholder. Add 4RMTECH's official ${T[kind].toLowerCase()} here. Have it reviewed by a qualified professional before publishing.</p></div></div>`;
  }
  function notFound() {
    return `<div class="page"><div class="container"><h1>Page not found</h1><div class="empty">We couldn't find that page.<br><a class="btn btn-primary" href="#/">Back to home</a></div></div></div>`;
  }

  /* ---------- router ---------- */
  let pendingScroll = null;
  function route() {
    const raw = location.hash.replace(/^#/, "") || "/";
    const [path, qs] = raw.split("?");
    const params = new URLSearchParams(qs || "");
    const seg = path.split("/").filter(Boolean);
    return { seg, params };
  }
  function render() {
    const { seg, params } = route();
    let html, after = () => {}, nav = "home";
    switch (seg[0]) {
      case undefined: html = homeView(); after = mountHome; break;
      case "shop":
        if (params.has("cat")) state.shop.cat = CATS.some(c => c.id === params.get("cat")) ? params.get("cat") : "all";
        if (params.has("q")) state.shop.q = params.get("q");
        if (params.get("offers")) state.shop.offerOnly = true;
        html = shopView(); after = mountShop; nav = "shop"; break;
      case "product": html = productView(seg[1]); after = () => mountProduct(seg[1]); nav = "shop"; break;
      case "cart": history.replaceState(null, "", "#/"); html = homeView(); after = () => { mountHome(); openCart(); }; break;
      case "checkout": html = checkoutView(); after = mountCheckout; nav = ""; break;
      case "wishlist": html = wishlistView(); nav = ""; break;
      case "account": html = accountView(); after = mountAccount; nav = ""; break;
      case "policy": html = policyView(seg[1]); nav = ""; break;
      default: html = notFound(); nav = "";
    }
    app.innerHTML = html;
    after();
    $$("#mainNav a").forEach(a => a.classList.toggle("active", !a.dataset.scroll && a.dataset.nav === nav));
    $("#mainNav").classList.remove("open"); $("#menuBtn").setAttribute("aria-expanded", "false");
    if (pendingScroll && seg[0] === undefined) {
      const el = document.getElementById(pendingScroll); if (el) el.scrollIntoView(); pendingScroll = null;
    } else window.scrollTo(0, 0);
    document.title = "4RMTECH | " + ({ shop: "Shop", product: (byId(seg[1]) || {}).name || "Product", cart: "Cart", checkout: "Checkout", wishlist: "Wishlist", account: "Account", policy: "Policy" }[seg[0]] || "Technology Store");
  }

  /* ---------- global events ---------- */
  document.addEventListener("click", e => {
    const t = e.target.closest("[data-add],[data-wish],[data-inc],[data-dec],[data-remove],[data-scroll],[data-open-cart],[data-close-cart]");
    if (!t) return;
    if (t.dataset.openCart !== undefined) { e.preventDefault(); openCart(); return; }
    if (t.dataset.closeCart !== undefined) { closeCart(); return; }
    if (t.dataset.scroll) {
      const id = t.dataset.scroll, isHome = !route().seg.length;
      if (isHome) { e.preventDefault(); document.getElementById(id).scrollIntoView({ behavior: "smooth" }); $("#mainNav").classList.remove("open"); }
      else pendingScroll = id;
      return;
    }
    if (t.dataset.add) { const p = byId(t.dataset.add); if (cart.add(p.id)) toast(`Added ${p.name} to cart`); }
    else if (t.dataset.wish) {
      const on = toggleWish(t.dataset.wish); t.setAttribute("aria-pressed", on);
      if (t.id === "dWish") t.textContent = on ? "♥ In wishlist" : "♡ Wishlist";
      toast(on ? "Added to wishlist" : "Removed from wishlist");
      if (route().seg[0] === "wishlist") render();
    }
    else if (t.dataset.inc) { const l = state.cart.find(i => i.id === Number(t.dataset.inc)); cart.setQty(t.dataset.inc, l.qty + 1); refreshCart(); }
    else if (t.dataset.dec) { const l = state.cart.find(i => i.id === Number(t.dataset.dec)); cart.setQty(t.dataset.dec, l.qty - 1); refreshCart(); }
    else if (t.dataset.remove) { cart.remove(t.dataset.remove); refreshCart(); toast("Removed from cart"); }
  });

  $("#searchForm").addEventListener("submit", e => {
    e.preventDefault();
    const q = $("#searchInput").value.trim();
    state.shop = { q, cat: "all", brands: [], max: 0, sort: "popular", offerOnly: false };
    if (location.hash.startsWith("#/shop")) render(); else location.hash = "#/shop";
  });
  $("#menuBtn").addEventListener("click", () => {
    const n = $("#mainNav"), open = n.classList.toggle("open");
    $("#menuBtn").setAttribute("aria-expanded", open);
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape") { closeCart(); $("#mainNav").classList.remove("open"); $("#menuBtn").setAttribute("aria-expanded", "false"); } });
  $("#closeCart").addEventListener("click", closeCart);
  overlay.addEventListener("click", closeCart);
  window.addEventListener("hashchange", () => { closeCart(); render(); });

  /* ---------- init ---------- */
  $$("[data-logo]").forEach(el => { el.outerHTML = logoSvg(); });
  $("#year").textContent = new Date().getFullYear();
  $("#footerCats").innerHTML = CATS.map(c => `<li><a href="#/shop?cat=${c.id}">${esc(c.name)}</a></li>`).join("");
  const soc = Object.entries(SITE.social || {}).filter(([, u]) => /^https?:\/\//.test(u));
  $("#socialLinks").innerHTML = soc.length
    ? soc.map(([n, u]) => `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${esc(n[0].toUpperCase() + n.slice(1))}</a>`).join("")
    : '<span class="muted" style="font-size:.85rem">Social links appear here once added in js/data.js.</span>';

  API.getProducts().then(list => { PRODUCTS = list.slice(); state.cart = state.cart.filter(i => byId(i.id)); state.wish = state.wish.filter(id => byId(id)); save(); updateBadges(); render(); });
  updateBadges();
})();
